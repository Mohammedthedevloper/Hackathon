<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
include 'db_connection.php';

// Helper
function e($s) { return htmlspecialchars($s ?? '', ENT_QUOTES, 'UTF-8'); }

// Current user
$currentUserId = $_SESSION['user_id'] ?? null;
$currentUser = null;
if ($currentUserId) {
    $stmt = $conn->prepare("SELECT user_id, username, full_name, profile_image FROM users WHERE user_id = ?");
    $stmt->bind_param("i", $currentUserId);
    $stmt->execute();
    $currentUser = $stmt->get_result()->fetch_assoc();
    $stmt->close();
}

// Handle like/comment/logout/add/delete
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Like toggle
    if (isset($_POST['like_post_id']) && $currentUserId) {
        $postId = (int)$_POST['like_post_id'];
        $chk = $conn->prepare("SELECT like_id FROM likes WHERE post_id = ? AND user_id = ?");
        $chk->bind_param("ii", $postId, $currentUserId);
        $chk->execute();
        $res = $chk->get_result();
        if ($res->num_rows > 0) {
            $del = $conn->prepare("DELETE FROM likes WHERE post_id = ? AND user_id = ?");
            $del->bind_param("ii", $postId, $currentUserId);
            $del->execute();
            $del->close();
        } else {
            $ins = $conn->prepare("INSERT INTO likes (post_id, user_id) VALUES (?, ?)");
            $ins->bind_param("ii", $postId, $currentUserId);
            $ins->execute();
            $ins->close();
        }
        $chk->close();
        header("Location: " . $_SERVER['PHP_SELF']);
        exit();
    }

    // Add comment
    if (isset($_POST['comment_post_id']) && isset($_POST['comment_text']) && $currentUserId) {
        $postId = (int)$_POST['comment_post_id'];
        $commentText = trim($_POST['comment_text']);
        if ($commentText !== '') {
            $stmt = $conn->prepare("INSERT INTO comments (post_id, user_id, comment_text) VALUES (?, ?, ?)");
            $stmt->bind_param("iis", $postId, $currentUserId, $commentText);
            $stmt->execute();
            $stmt->close();
        }
        header("Location: " . $_SERVER['PHP_SELF']);
        exit();
    }

    // Add post
    if (isset($_POST['new_post']) && $currentUserId) {
        $content = trim($_POST['content']);
        $imagePath = null;

        if (!empty($_FILES['image']['name'])) {
            $targetDir = "images/";
            $imagePath = basename($_FILES['image']['name']);
            $targetFile = $targetDir . $imagePath;
            move_uploaded_file($_FILES['image']['tmp_name'], $targetFile);
        }

        if ($content !== '' || $imagePath) {
            $stmt = $conn->prepare("INSERT INTO posts (user_id, content, image) VALUES (?, ?, ?)");
            $stmt->bind_param("iss", $currentUserId, $content, $imagePath);
            $stmt->execute();
            $stmt->close();
        }
        header("Location: " . $_SERVER['PHP_SELF']);
        exit();
    }

    // Delete post
    if (isset($_POST['delete_post_id']) && $currentUserId) {
        $postId = (int)$_POST['delete_post_id'];
        $conn->query("DELETE FROM posts WHERE post_id=$postId AND user_id=$currentUserId");
        header("Location: " . $_SERVER['PHP_SELF']);
        exit();
    }

    // Logout
    if (isset($_POST['action']) && $_POST['action'] === 'logout') {
        session_unset();
        session_destroy();
        header("Location: index.php");
        exit();
    }
}

// Fetch posts
$posts_sql = "
    SELECT p.post_id, p.user_id, p.content, p.image, p.created_at,
           u.full_name AS author, u.username, u.profile_image
    FROM posts p
    JOIN users u ON p.user_id = u.user_id
    ORDER BY p.created_at DESC
";
$posts_result = $conn->query($posts_sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Campus Connect | Posts</title>
<style>
body { margin:0; padding:0; font-family:sans-serif; background:#f9fafb; color:#111827; }
a { text-decoration:none; color:inherit; }

/* Header */
header {
  position:fixed; top:0; left:0; right:0; height:60px;
  background:#fff; display:flex; align-items:center; justify-content:space-between;
  padding:0 20px; box-shadow:0 6px 18px rgba(0,0,0,0.08); z-index:1000;
}
.brand { display:flex; align-items:center; gap:12px; }
.logo { width:48px; height:48px; border-radius:8px; overflow:hidden; background:#1e3a8a; display:flex; align-items:center; justify-content:center; }
.logo img { width:100%; height:100%; object-fit:cover; }
.site-title { font-weight:700; font-size:20px; color:#1e3a8a; }
nav { display:flex; gap:12px; align-items:center; }
nav a { padding:8px 14px; border-radius:8px; font-weight:600; color:#6b7280; transition:0.2s; }
nav a.active, nav a:hover { background:rgba(30,58,138,0.1); color:#1e3a8a; }
.login-btn, .signup-btn, .logout-btn { padding:8px 16px; border-radius:8px; border:none; font-weight:600; cursor:pointer; transition:0.2s; }
.login-btn { background:white; color:#1e3a8a; border:1px solid #1e3a8a; }
.signup-btn { background:#1e3a8a; color:white; }
.logout-btn { background:#ef4444; color:#fff; border:1px solid #ef4444; }
.signup-btn:hover, .login-btn:hover, .logout-btn:hover { opacity:0.9; }

/* Layout */
.main-content {
  display:flex; flex-wrap:wrap;
  gap:20px; max-width:1100px;
  margin:80px auto; padding:20px;
}
.feed { flex:1 1 65%; }
.sidebar { flex:1 1 30%; }

.card {
  background:#fff; padding:15px; border-radius:12px;
  box-shadow:0 4px 12px rgba(0,0,0,0.05);
  border:1px solid #e5e7eb; margin-bottom:20px;
}
.post-header { display:flex; align-items:center; gap:10px; margin-bottom:8px; }
.avatar { width:48px; height:48px; border-radius:50%; overflow:hidden; background:#e5e7eb; display:flex; align-items:center; justify-content:center; font-weight:700; color:#1f2937; }
.avatar img { width:100%; height:100%; object-fit:cover; }
.post-image { width:100%; border-radius:8px; margin-top:10px; max-height:400px; object-fit:cover; }
.actions { display:flex; gap:12px; margin-top:10px; }
.actions button { padding:6px 12px; border:none; border-radius:20px; cursor:pointer; font-weight:600; transition:0.2s; }
.actions button.like-btn { color:#ef4444; }
.actions button.comment-btn { color:#1e3a8a; }
.comment { background:#f8fafc; border-radius:8px; padding:10px; margin-top:8px; }
.comment small { color:#6b7280; display:block; margin-top:4px; font-size:12px; }

/* Add Post Card */
.add-post-card {
  background:#fff; border-radius:12px; padding:20px;
  box-shadow:0 4px 14px rgba(0,0,0,0.08);
  border:1px solid #e5e7eb;
}
.add-post-card h3 { color:#1e3a8a; margin-bottom:12px; }
.add-post-card textarea {
  width:100%; height:80px; border:1px solid #e5e7eb; border-radius:8px;
  padding:10px; resize:none; font-family:sans-serif;
}
.add-post-card input[type="file"] { margin-top:8px; }
.add-post-card button {
  margin-top:10px; background:#1e3a8a; color:white;
  padding:8px 16px; border:none; border-radius:8px;
  font-weight:600; cursor:pointer; transition:0.2s;
}
.add-post-card button:hover { background:#153e75; }
.footer { text-align:center; color:#6b7280; padding:20px; }
</style>
</head>
<body>

<header>
  <div class="brand">
    <div class="logo"><img src="images/logo.jpg" alt="Logo"></div>
    <span class="site-title">Campus Connect</span>
  </div>
  <nav>
    <a href="index.php">Home</a>
    <a href="about.php">About</a>
    <a href="profile.php">Profile</a>
    <a href="events.php">Events</a>
    <a href="messaging.php">Chats</a>
    <a href="posts.php" class="active">Posts</a>
    <?php if ($currentUser): ?>
      <form method="POST" style="display:inline;">
        <input type="hidden" name="action" value="logout">
        <button type="submit" class="logout-btn">Logout</button>
      </form>
    <?php else: ?>
      <a href="login.php" class="login-btn">Login</a>
      <a href="register.php" class="signup-btn">Sign Up</a>
    <?php endif; ?>
  </nav>
</header>

<div class="main-content">
  <div class="feed">
    <?php if ($posts_result && $posts_result->num_rows > 0): ?>
      <?php while ($p = $posts_result->fetch_assoc()): ?>
        <?php
        $likesCount = $conn->query("SELECT COUNT(*) AS c FROM likes WHERE post_id=" . (int)$p['post_id'])->fetch_assoc()['c'];
        $userLiked = false;
        if ($currentUserId) {
          $res = $conn->query("SELECT 1 FROM likes WHERE post_id=" . (int)$p['post_id'] . " AND user_id=" . (int)$currentUserId);
          $userLiked = $res->num_rows > 0;
        }
        $commentsRes = $conn->query("
          SELECT c.comment_text, c.created_at, u.full_name, u.username 
          FROM comments c JOIN users u ON c.user_id = u.user_id
          WHERE c.post_id = " . (int)$p['post_id'] . " ORDER BY c.created_at ASC
        ");
        ?>
        <div class="card">
          <div class="post-header">
            <div class="avatar">
              <?php if(!empty($p['profile_image'])): ?>
                <img src="images/<?php echo e($p['profile_image']); ?>" alt="">
              <?php else: ?>
                <?php echo strtoupper(substr($p['author'] ?: $p['username'],0,1)); ?>
              <?php endif; ?>
            </div>
            <div>
              <strong><?php echo e($p['author'] ?: $p['username']); ?></strong><br>
              <small style="color:#6b7280;"><?php echo date("M j, Y g:i a", strtotime($p['created_at'])); ?></small>
            </div>
          </div>
          <p><?php echo nl2br(e($p['content'])); ?></p>
          <?php if(!empty($p['image'])): ?><img src="images/<?php echo e($p['image']); ?>" class="post-image" alt="Post"><?php endif; ?>

          <div class="actions">
            <?php if($currentUser): ?>
              <form method="POST" style="display:inline;">
                <input type="hidden" name="like_post_id" value="<?php echo (int)$p['post_id']; ?>">
                <button type="submit" class="like-btn"><?php echo $userLiked ? '❤️' : '🤍'; ?> <?php echo $likesCount; ?></button>
              </form>
              <button class="comment-btn" onclick="document.getElementById('comment-input-<?php echo (int)$p['post_id']; ?>').focus();">💬 Comment</button>
              <?php if($p['user_id'] == $currentUserId): ?>
                <form method="POST" style="display:inline;">
                  <input type="hidden" name="delete_post_id" value="<?php echo (int)$p['post_id']; ?>">
                  <button type="submit" style="color:#ef4444;background:#fee2e2;border-radius:20px;padding:6px 12px;border:none;cursor:pointer;">🗑️ Delete</button>
                </form>
              <?php endif; ?>
            <?php else: ?>
              <button disabled>❤️ <?php echo $likesCount; ?></button>
              <button disabled>💬 Comment</button>
            <?php endif; ?>
          </div>

          <div>
            <?php if($commentsRes && $commentsRes->num_rows>0): ?>
              <?php while($c = $commentsRes->fetch_assoc()): ?>
                <div class="comment">
                  <strong><?php echo e($c['full_name'] ?: $c['username']); ?>:</strong>
                  <div><?php echo nl2br(e($c['comment_text'])); ?></div>
                  <small><?php echo date("M j, Y g:i a", strtotime($c['created_at'])); ?></small>
                </div>
              <?php endwhile; ?>
            <?php else: ?>
              <div class="comment" style="background:#fff;border:1px dashed #e5e7eb;color:#9ca3af;">No comments yet.</div>
            <?php endif; ?>
          </div>

          <?php if($currentUser): ?>
            <form method="POST" style="margin-top:8px;">
              <input type="hidden" name="comment_post_id" value="<?php echo (int)$p['post_id']; ?>">
              <input id="comment-input-<?php echo (int)$p['post_id']; ?>" type="text" name="comment_text" placeholder="Write a comment..." style="width:100%;padding:10px;border-radius:8px;border:1px solid #e5e7eb;">
            </form>
          <?php endif; ?>
        </div>
      <?php endwhile; ?>
    <?php else: ?>
      <p>No posts found.</p>
    <?php endif; ?>
  </div>

  <div class="sidebar">
    <div class="add-post-card">
      <?php if($currentUser): ?>
        <h3>✨ Create a New Post</h3>
        <form method="POST" enctype="multipart/form-data">
          <textarea name="content" placeholder="What's happening on campus?" required></textarea>
          <input type="file" name="image" accept="image/*">
          <button type="submit" name="new_post">Post</button>
        </form>
      <?php else: ?>
        <h3>👋 Welcome!</h3>
        <p style="color:#6b7280;">Login to share your thoughts, updates, or campus photos.</p>
        <a href="login.php"><button>Login</button></a>
      <?php endif; ?>
    </div>
  </div>
</div>

<footer class="footer">
  &copy; <?php echo date('Y'); ?> Campus Connect. All rights reserved.
</footer>

</body>
</html>
