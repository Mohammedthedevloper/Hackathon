<?php
session_set_cookie_params(['httponly'=>true,'samesite'=>'Lax']);
session_start();
session_unset();
session_destroy();
header('Location: index.php');
exit();