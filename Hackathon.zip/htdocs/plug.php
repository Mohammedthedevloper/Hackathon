<?php
// plug.php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
include 'db_connection.php';

// ---------- LOGOUT HANDLER ----------
if (isset($_POST['action']) && $_POST['action'] === 'logout') {
    session_unset();
    session_destroy();
    header("Location: login.php");
    exit();
}

// Check if user is logged in
if (empty($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$currentUserId = $_SESSION['user_id'];


// ---------- TUTOR ACTIONS ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Add tutor
    if (isset($_POST['action']) && $_POST['action'] === 'add_tutor') {
        $tutor_name = $conn->real_escape_string($_POST['tutor_name']);
        $faculty = $conn->real_escape_string($_POST['faculty']);
        $module = $conn->real_escape_string($_POST['module']);
        $bio = $conn->real_escape_string($_POST['bio']);

        // Check if already a tutor
        $check = $conn->prepare("SELECT * FROM tutors WHERE user_id = ?");
        $check->bind_param("i", $currentUserId);
        $check->execute();
        $res = $check->get_result();

        if ($res->num_rows === 0) {
            $stmt = $conn->prepare("INSERT INTO tutors (user_id, tutor_name, faculty, module, bio, created_at) VALUES (?, ?, ?, ?, ?, NOW())");
            $stmt->bind_param("issss", $currentUserId, $tutor_name, $faculty, $module, $bio);
            $stmt->execute();
            $stmt->close();
            header("Location: plug.php"); // refresh page
            exit();
        } else {
            $error = "You are already a tutor!";
        }
        $check->close();
    }

    // Delete tutor profile
    if (isset($_POST['action']) && $_POST['action'] === 'delete_tutor') {
        $stmt = $conn->prepare("DELETE FROM tutors WHERE user_id = ?");
        $stmt->bind_param("i", $currentUserId);
        $stmt->execute();
        $stmt->close();
        header("Location: plug.php");
        exit();
    }
}

// Get current user info
$stmt = $conn->prepare("SELECT user_id, full_name, profile_image FROM users WHERE user_id = ?");
$stmt->bind_param("i", $currentUserId);
$stmt->execute();
$currentUser = $stmt->get_result()->fetch_assoc();
$stmt->close();

// Handle search
$search = isset($_GET['search']) ? $_GET['search'] : '';
$search_sql = $conn->real_escape_string($search);

// Fetch tutors + unread message count
$tutors_sql = "
    SELECT 
        t.*, 
        u.full_name, 
        u.profile_image,
        (
            SELECT COUNT(*) 
            FROM messages 
            WHERE sender_id = t.user_id 
              AND receiver_id = $currentUserId 
              AND is_read = 0
        ) AS unread_count,
        (
            SELECT MAX(created_at)
            FROM messages 
            WHERE (sender_id = t.user_id AND receiver_id = $currentUserId)
               OR (sender_id = $currentUserId AND receiver_id = t.user_id)
        ) AS last_message_time
    FROM tutors t 
    LEFT JOIN users u ON t.user_id = u.user_id
    WHERE t.tutor_name LIKE '%$search_sql%' 
       OR t.module LIKE '%$search_sql%'
       OR t.faculty LIKE '%$search_sql%'
    ORDER BY unread_count DESC, last_message_time DESC, t.created_at DESC
";

$tutors_result = $conn->query($tutors_sql);


?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width,initial-scale=1" />
<title>Plug | Find Tutors</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700&display=swap" rel="stylesheet">
<style>
:root{--primary:#1e3a8a;--muted:#6b7280;--bg:#f7f8fb;--card:#fff;--radius:12px;--shadow:0 10px 30px rgba(2,6,23,0.08);}
body{margin:0;font-family:'Inter',sans-serif;color:#0f172a;background:var(--bg);}
header{
  position:fixed; top:0; left:0; right:0; height:68px;
  display:flex; align-items:center; padding:0 22px; gap:16px;
  z-index:1200;
  background: linear-gradient(180deg, rgba(255,255,255,0.98), rgba(255,255,255,0.96));
  box-shadow: 0 8px 30px rgba(2,6,23,0.08);
  backdrop-filter: blur(6px);
}
/* brand left */
.brand { display:flex; align-items:center; gap:12px; }
.logo { width:52px; height:52px; border-radius:10px; overflow:hidden; background:var(--primary); display:flex; align-items:center; justify-content:center; }
.logo img { width:100%; height:100%; object-fit:cover; }
.site-title { font-weight:700; color:var(--primary); font-size:18px; }

.brand{display:flex;align-items:center;gap:12px;}
.site-title{font-weight:700;color:var(--primary);font-size:18px;}
nav{margin-left:auto;display:flex;align-items:center;gap:10px;}
nav a{padding:8px 12px;border-radius:10px;color:var(--muted);font-weight:600;text-decoration:none;}
nav a.active,nav a:hover{background:rgba(30,58,138,0.08);color:var(--primary);}
.logout-btn{padding:8px 12px;border:none;border-radius:8px;background:#ef4444;color:#fff;font-weight:600;cursor:pointer;}
.logout-btn:hover{background:#dc2626;}
main.container{max-width:1200px;margin:92px auto 24px;display:flex;gap:22px;}
.main{flex:3;display:flex;flex-direction:column;gap:18px;}
aside{flex:1;display:flex;flex-direction:column;gap:16px;position:sticky;top:92px;}
.card{background:var(--card);border-radius:var(--radius);padding:14px;box-shadow:var(--shadow);border:1px solid rgba(2,6,23,0.04);}
.tutor-card{display:flex;gap:12px;align-items:flex-start;}
.tutor-card img{width:64px;height:64px;border-radius:12px;object-fit:cover;}
.tutor-info{flex:1;}
.tutor-info h3{margin:0;font-size:18px;}
.tutor-info p{margin:4px 0;color:var(--muted);}
.message-btn{padding:6px 10px;background:var(--primary);color:#fff;border:none;border-radius:8px;cursor:pointer;}
.message-btn:hover{background:#2563eb;}
input.search-box{padding:8px 12px;border-radius:10px;border:1px solid #ddd;width:100%;margin-bottom:12px;}
/* Sidebar form styling */
aside .card h4 {
    margin-top: 0;
    font-size: 18px;
    color: var(--primary);
}

aside .card form {
    display: flex;
    flex-direction: column;
    gap: 10px;
}

aside .card input,
aside .card textarea {
    padding: 8px 12px;
    border-radius: 8px;
    border: 1px solid #ddd;
    font-size: 14px;
    width: 100%;
    box-sizing: border-box;
}

aside .card textarea {
    resize: vertical;
    min-height: 60px;
}

aside .card button {
    padding: 10px 12px;
    border: none;
    border-radius: 8px;
    background: var(--primary);
    color: #fff;
    font-weight: 600;
    cursor: pointer;
    transition: background 0.3s ease;
}

aside .card button:hover {
    background: #2563eb; /* darker shade on hover */
}

/* Delete button specific style */
aside .card form button[value="delete_tutor"] {
    background: #ef4444;
}

aside .card form button[value="delete_tutor"]:hover {
    background: #dc2626;
}
/* 🔔 Message Notification Styles */
.has-message {
  position: relative;
  border: 2px solid #1e3a8a; /* main accent */
  box-shadow: 0 0 15px rgba(30,58,138,0.25);
  animation: pulseMessage 1.5s infinite;
  transition: all 0.3s ease;
}

/* glowing animation */
@keyframes pulseMessage {
  0% { box-shadow: 0 0 10px rgba(30,58,138,0.2); }
  50% { box-shadow: 0 0 20px rgba(30,58,138,0.4); }
  100% { box-shadow: 0 0 10px rgba(30,58,138,0.2); }
}

/* badge showing unread message count */
.message-badge {
  display: inline-block;
  background: #1e3a8a;
  color: #fff;
  padding: 2px 8px;
  border-radius: 9999px;
  font-size: 12px;
  margin-left: 8px;
  font-weight: 600;
  box-shadow: 0 2px 8px rgba(30,58,138,0.3);
  vertical-align: middle;
}

/* subtle hover feedback for tutor cards */
.tutor-card:hover {
  transform: translateY(-3px);
  transition: transform 0.2s ease;
}

</style>
</head>
<body>

<header id="pageHeader">
  <div class="brand">
    <div class="logo"><img src="images/logo.jpg" alt="Logo"></div>
    <span class="site-title">Campus Connect</span>
  </div>

  <nav>
    <a href="index.php" >Home</a>
    <a href="about.php">About</a>
    <a href="profile.php">Profile</a>
    <a href="events.php">Events</a>
    <a href="plug.php" class="active">Plug In | Tutor Board</a>

    <form method="POST" style="display:inline;margin-left:6px;">
        <input type="hidden" name="action" value="logout">
        <button type="submit" class="logout-btn">Logout</button>
    </form>
  </nav>
</header>

<main class="container">
  <div class="main">
    <form method="GET">
      <input type="text" name="search" class="search-box" placeholder="Search tutors by name, module, or faculty" value="<?php echo htmlspecialchars($search); ?>">
    </form>

    <?php if ($tutors_result && $tutors_result->num_rows>0): ?>
        <?php while ($t = $tutors_result->fetch_assoc()): ?>
            <div class="card tutor-card <?php echo ($t['unread_count'] > 0) ? 'has-message' : ''; ?>">

                <?php if(!empty($t['profile_image'])): ?>
                    <img src="images/<?php echo htmlspecialchars($t['profile_image']); ?>" alt="Profile">
                <?php else: ?>
                    <img src="images/default_avatar.png" alt="Profile">
                <?php endif; ?>
                <div class="tutor-info">
                    <h3><?php echo htmlspecialchars($t['tutor_name']); ?></h3>
            <?php if ($t['unread_count'] > 0): ?>
    <span class="message-badge">New Message</span>
<?php endif; ?>


                    <p><strong>Faculty:</strong> <?php echo htmlspecialchars($t['faculty']); ?></p>
                    <p><strong>Module:</strong> <?php echo htmlspecialchars($t['module']); ?></p>
                    <p><?php echo htmlspecialchars($t['bio']); ?></p>
                    <button class="message-btn" onclick="window.location.href='tutor_messaging.php?to=<?php echo $t['user_id']; ?>'">Message</button>
                </div>
            </div>
        <?php endwhile; ?>
    <?php else: ?>
        <p>No tutors found.</p>
    <?php endif; ?>
  </div>
<aside>
  <?php
    // Check if user is a tutor
    $checkTutor = $conn->prepare("SELECT * FROM tutors WHERE user_id = ?");
    $checkTutor->bind_param("i", $currentUserId);
    $checkTutor->execute();
    $isTutor = ($checkTutor->get_result()->num_rows > 0);
    $checkTutor->close();
  ?>

  <!-- Show signup form only if user is NOT a tutor -->
  <?php if(!$isTutor): ?>
    <div class="card">
      <h4>Become a Tutor</h4>
      <?php if(isset($error)) echo "<p style='color:red;'>{$error}</p>"; ?>
      <form method="POST">
        <input type="text" name="tutor_name" placeholder="Your name" required>
        <input type="text" name="faculty" placeholder="Faculty" required>
        <input type="text" name="module" placeholder="Module" required>
        <textarea name="bio" placeholder="Short bio" required></textarea>
        <button type="submit" name="action" value="add_tutor">Sign Up as Tutor</button>
      </form>
    </div>
  <?php endif; ?>

  <!-- Delete Tutor Profile Button (show only if they ARE a tutor) -->
  <?php if($isTutor): ?>
    <div class="card">
      <form method="POST">
        <button type="submit" name="action" value="delete_tutor" style="background:#ef4444;color:#fff;padding:8px 12px;border:none;border-radius:8px;cursor:pointer;">
          Delete My Tutor Profile
        </button>
      </form>
    </div>
  <?php endif; ?>
</aside>


</main>

</body>
</html>
