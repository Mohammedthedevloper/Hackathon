<?php
$host = "sql102.infinityfree.com";
$user = "if0_40032620";
$pass = "EduvosUmhlanga";
$db   = "if0_40032620_webappdb"; 

$conn = new mysqli($host, $user, $pass, $db);

// Check connection
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}
?>
