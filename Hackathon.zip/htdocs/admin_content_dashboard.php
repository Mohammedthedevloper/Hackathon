<?php
// --- Protect: admins only ---
session_set_cookie_params(['httponly'=>true,'samesite'=>'Lax']);
session_start();
if (!isset($_SESSION['user_id'], $_SESSION['role']) || $_SESSION['role'] !== 'admin') {
  header('Location: login.php'); exit();
}

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include 'db_connection.php';
function e($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }

$currentUserId = (int)($_SESSION['user_id'] ?? 1);

/* Helpers */
function table_exists(mysqli $conn, string $name): bool {
    $name_esc = $conn->real_escape_string($name);
    $res = $conn->query("SHOW TABLES LIKE '{$name_esc}'");
    return $res && $res->num_rows > 0;
}
function total_rows(mysqli $conn, string $table): int {
    if (!table_exists($conn, $table)) return 0;
    $res = $conn->query("SELECT COUNT(*) AS c FROM `{$table}`");
    if (!$res) return 0;
    $row = $res->fetch_assoc();
    return isset($row['c']) ? (int)$row['c'] : 0;
}
function safe_query(mysqli $conn, string $sql){ return $conn->query($sql); }

/* Totals */
$total_events   = total_rows($conn, 'events');
$total_posts    = total_rows($conn, 'posts');
$total_likes    = total_rows($conn, 'likes');
$total_comments = total_rows($conn, 'comments');
$total_tutors   = total_rows($conn, 'tutors');

/* Lists */
$events = $total_events ? safe_query($conn, "
  SELECT e.event_id, e.title, e.description, e.date_time, e.location, e.image, e.created_by,
         u.username, u.full_name
  FROM events e
  LEFT JOIN users u ON u.user_id = e.created_by
  ORDER BY e.date_time DESC
  LIMIT 20
") : null;

$posts = $total_posts ? safe_query($conn, "
  SELECT p.post_id, p.content, p.image, p.created_at, p.user_id,
         u.username, u.full_name
  FROM posts p
  LEFT JOIN users u ON u.user_id = p.user_id
  ORDER BY p.created_at DESC
  LIMIT 20
") : null;

$likes = (table_exists($conn,'likes') && table_exists($conn,'posts') && table_exists($conn,'users')) ? safe_query($conn, "
  SELECT l.like_id, l.post_id, l.user_id, l.created_at,
         COALESCE(u.full_name, u.username) AS liker_name,
         p.content AS post_content
  FROM likes l
  JOIN users u ON u.user_id = l.user_id
  JOIN posts p ON p.post_id = l.post_id
  ORDER BY l.created_at DESC
  LIMIT 20
") : null;

$comments = (table_exists($conn,'comments') && table_exists($conn,'users')) ? safe_query($conn, "
  SELECT c.comment_id, c.post_id, c.user_id, c.comment_text, c.created_at,
         COALESCE(u.full_name, u.username) AS commenter_name
  FROM comments c
  JOIN users u ON u.user_id = c.user_id
  ORDER BY c.created_at DESC
  LIMIT 20
") : null;

$tutors = $total_tutors ? safe_query($conn, "
  SELECT id, tutor_name, email, year_level, faculty, module, bio, created_at, updated_at
  FROM tutors
  ORDER BY updated_at DESC, created_at DESC
  LIMIT 20
") : null;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Campus Connect | Content Dashboard</title>

<style>
:root{
  --brand:#1e3a8a; --brand-2:#0f2a6a;
  --bg:#0b1220;       /* dark canvas */
  --panel:#0f172a;    /* cards background */
  --panel-2:#0d1526;  /* header/nav background */
  --ink:#e5e7eb;      /* body text */
  --muted:#99a2b8;    /* secondary text */
  --accent:#60a5fa;   /* lines / focus */
  --good:#22c55e; --warn:#f59e0b; --bad:#ef4444;
  --chip:#19233a;     /* badge bg */
  --border:#1e293b;
  --shadow:0 12px 40px rgba(0,0,0,.35);
  --radius:14px;
}

/* Base */
*{box-sizing:border-box}
html,body{height:100%}
body{
  margin:0; font-family: Inter, system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial, sans-serif;
  color:var(--ink); background:
    radial-gradient(1200px 600px at -10% -10%, #1f2a44 0%, transparent 40%),
    radial-gradient(900px 500px at 110% -10%, #132348 0%, transparent 45%),
    radial-gradient(800px 500px at 50% 120%, #16243d 0%, transparent 50%),
    var(--bg);
  -webkit-font-smoothing:antialiased;
}
a{color:inherit; text-decoration:none}

/* Header */
header{
  position:fixed; inset:0 0 auto 0; height:70px; z-index:1000;
  display:flex; align-items:center; justify-content:space-between; gap:14px;
  padding:0 18px; background:linear-gradient(180deg,rgba(13,21,38,.95),rgba(13,21,38,.9));
  border-bottom:1px solid var(--border);
  box-shadow:var(--shadow);
}
.brand{display:flex; align-items:center; gap:12px}
.logo{width:46px;height:46px;border-radius:12px;overflow:hidden;background:var(--brand);display:flex;align-items:center;justify-content:center; box-shadow:0 10px 20px rgba(30,58,138,.35)}
.logo img{width:100%;height:100%;object-fit:cover}
.site-title{font-weight:800;color:#fff;letter-spacing:.2px}
nav{display:flex;align-items:center;gap:10px}
nav a{padding:8px 12px;border-radius:10px;font-weight:600;color:var(--muted);transition:.18s}
nav a:hover, nav a.active{background:rgba(96,165,250,.12); color:#dbeafe}
.logout-form{margin:0}
.logout-btn{
  padding:8px 12px;border:none;border-radius:10px;background:var(--bad);color:#fff;font-weight:700;cursor:pointer;
  box-shadow:0 6px 16px rgba(239,68,68,.28); transition:.18s;
}
.logout-btn:hover{filter:brightness(.96)}

/* Layout */
.container{
  max-width:1200px; margin:0 auto; padding:100px 18px 28px;
  display:flex; flex-direction:column; gap:18px;
}

/* Section headers */
.section-title{
  display:flex; align-items:center; gap:10px; font-weight:800; color:#dbeafe;
  padding:10px 12px; border-radius:12px; background: linear-gradient(180deg, rgba(96,165,250,.14), rgba(96,165,250,.04));
  border:1px solid rgba(96,165,250,.25);
}
.section-title .emoji{font-size:20px}

/* Cards */
.card{
  background: linear-gradient(180deg, rgba(15,23,42,.96), rgba(15,23,42,.92));
  border:1px solid var(--border);
  border-radius:var(--radius); box-shadow:var(--shadow); padding:16px;
}

/* Stats */
.stats{display:grid; grid-template-columns:repeat(5,minmax(0,1fr)); gap:14px}
.stat{
  background:linear-gradient(180deg, #0f1a34, #0c152b);
  border:1px solid var(--border);
  border-radius:16px; padding:16px; text-align:center;
  box-shadow:inset 0 1px 0 rgba(255,255,255,.04), 0 10px 24px rgba(2,6,23,.45);
}
.stat h3{margin:0; font-size:12px; color:var(--muted); letter-spacing:.3px}
.stat p{margin:6px 0 0; font-size:26px; font-weight:900; color:#eaf2ff}
.stat .chip{display:inline-block;margin-top:6px;padding:2px 8px;border-radius:999px;background:var(--chip);color:#bcd3ff;font-size:11px;}

/* Forms */
form label{display:block; font-size:12px; color:var(--muted); margin:0 0 6px 2px}
form input, form textarea, form select{
  width:100%; padding:10px 12px; border:1px solid var(--border); border-radius:10px; background:#0b1326; color:#e5e9f5; outline:none;
}
form input::file-selector-button{
  background:#0c1a36; color:#dbeafe; border:1px solid var(--border); padding:8px 10px; border-radius:8px; margin-right:10px; cursor:pointer;
}
form input:focus, form textarea:focus, form select:focus{
  border-color:#284fb5; box-shadow:0 0 0 3px rgba(99,102,241,.25);
}
form .grid{display:grid; gap:12px}
form .grid2{grid-template-columns:1fr 1fr}
form .full{grid-column:1 / -1}

/* Buttons */
button{cursor:pointer}
.btn{
  padding:9px 12px; border:none; border-radius:10px; font-weight:800; transition:transform .06s ease, filter .18s;
}
.btn:active{transform:translateY(1px)}
.btn-primary{background:linear-gradient(135deg,#2a51c5,#1e3a8a); color:#fff; box-shadow:0 10px 28px rgba(46,64,153,.35)}
.btn-primary:hover{filter:brightness(.98)}
.btn-danger{background:linear-gradient(135deg,#ef4444,#b91c1c); color:#fff; box-shadow:0 10px 28px rgba(239,68,68,.35)}
.btn-warning{background:linear-gradient(135deg,#f59e0b,#b45309); color:#fff; box-shadow:0 10px 28px rgba(245,158,11,.35)}

/* Tables */
.table-wrap{ border-radius:14px; overflow:hidden; border:1px solid var(--border); background:#0c152b }
table{width:100%; border-collapse:separate; border-spacing:0; }
thead th{
  position:sticky; top:0; z-index:1;
  background:linear-gradient(180deg,#0f1b36,#0e1830);
  color:#cbd5e1; letter-spacing:.3px;
  font-weight:900; font-size:12px; padding:12px; text-align:left; border-bottom:1px solid var(--border);
}
tbody tr:nth-child(odd){ background:rgba(255,255,255,.01) }
tbody tr:hover{ background:rgba(96,165,250,.06) }
tbody td{padding:12px; border-bottom:1px solid rgba(255,255,255,.03); vertical-align:top; font-size:14px; color:#e5e7eb}
td.nowrap{white-space:nowrap}
.td-clip{max-width:520px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis}
.small{font-size:12px;color:var(--muted)}

/* Responsive */
@media (max-width:1120px){ .stats{grid-template-columns:repeat(3,minmax(0,1fr))} }
@media (max-width:820px){
  .site-title{display:none}
  .stats{grid-template-columns:repeat(2,minmax(0,1fr))}
  form .grid2{grid-template-columns:1fr}
}
@media (max-width:560px){
  .container{padding-left:14px; padding-right:14px}
  .stats{grid-template-columns:1fr}
  .td-clip{max-width:220px}
}
</style>
</head>
<body>
<header>
  <div class="brand">
    <div class="logo"><img src="images/logo.jpg" alt="Logo"></div>
    <span class="site-title">Campus Connect — Admin</span>
  </div>
  <nav>
    <a href="admin_content_dashboard.php" class="active">Content</a>
    <a href="admin_dashboard.php">Users</a>
    <form action="logout.php" method="post" class="logout-form">
      <button type="submit" class="logout-btn">Logout</button>
    </form>
  </nav>
</header>

<div class="container">

  <!-- Stats -->
  <div class="stats">
    <div class="stat"><h3>Events</h3><p><?php echo $total_events; ?></p><span class="chip">Latest 20 shown</span></div>
    <div class="stat"><h3>Posts</h3><p><?php echo $total_posts; ?></p><span class="chip">Feed items</span></div>
    <div class="stat"><h3>Likes</h3><p><?php echo $total_likes; ?></p><span class="chip">Engagement</span></div>
    <div class="stat"><h3>Comments</h3><p><?php echo $total_comments; ?></p><span class="chip">Discussions</span></div>
    <div class="stat"><h3>Tutors</h3><p><?php echo $total_tutors; ?></p><span class="chip">Directory</span></div>
  </div>

  <!-- Add Event -->
  <div class="section-title"><span class="emoji">🗓️</span> Add Event</div>
  <div class="card">
    <form id="addEventForm" onsubmit="return addEvent(event)" enctype="multipart/form-data">
      <div class="grid grid2">
        <div><label>Title</label><input type="text" name="title" required maxlength="200"></div>
        <div><label>Date & Time</label><input type="datetime-local" name="date_time" required></div>
        <div><label>Location</label><input type="text" name="location" required></div>
        <div><label>Image</label><input type="file" name="image" accept="image/*"></div>
        <div class="full"><label>Description</label><textarea name="description" rows="3" placeholder="Optional details…"></textarea></div>
      </div>
      <input type="hidden" name="created_by" value="<?php echo (int)$currentUserId; ?>">
      <button class="btn btn-primary" type="submit">Add Event</button>
    </form>
  </div>

  <!-- Events Table -->
  <div class="section-title"><span class="emoji">📅</span> Events (Latest 20)</div>
  <div class="table-wrap">
    <table>
      <thead><tr><th style="width:70px">ID</th><th>Title</th><th>Date</th><th>Created By</th><th class="nowrap">Actions</th></tr></thead>
      <tbody id="eventTable">
        <?php if($events && $events instanceof mysqli_result && $events->num_rows): while($e=$events->fetch_assoc()): ?>
          <tr data-id="<?= (int)$e['event_id'] ?>">
            <td class="nowrap"><?= (int)$e['event_id'] ?></td>
            <td class="td-clip"><?= e($e['title']) ?></td>
            <td class="nowrap"><?= date('j M Y, H:i', strtotime($e['date_time'])) ?></td>
            <td class="td-clip"><?= e($e['full_name'] ?: $e['username'] ?: 'user_id '.$e['created_by']) ?></td>
            <td class="nowrap">
              <button class="btn btn-warning" onclick="editEvent(<?= (int)$e['event_id'] ?>)">Edit</button>
              <button class="btn btn-danger" onclick="deleteEvent(<?= (int)$e['event_id'] ?>)">Delete</button>
            </td>
          </tr>
        <?php endwhile; else: ?><tr><td colspan="5" class="small">No events found.</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>

  <!-- Add Post -->
  <div class="section-title"><span class="emoji">📝</span> Add Post</div>
  <div class="card">
    <form id="addPostForm" onsubmit="return addPost(event)" enctype="multipart/form-data">
      <div class="grid">
        <div><label>Content</label><textarea name="content" required rows="3" placeholder="Share an update…"></textarea></div>
        <div><label>Image</label><input type="file" name="image" accept="image/*"></div>
      </div>
      <input type="hidden" name="user_id" value="<?php echo (int)$currentUserId; ?>">
      <button class="btn btn-primary" type="submit">Add Post</button>
    </form>
  </div>

  <!-- Posts Table -->
  <div class="section-title"><span class="emoji">📰</span> Posts (Latest 20)</div>
  <div class="table-wrap">
    <table>
      <thead><tr><th style="width:70px">ID</th><th>Author</th><th>Content</th><th>Date</th><th class="nowrap">Actions</th></tr></thead>
      <tbody id="postTable">
        <?php if($posts && $posts instanceof mysqli_result && $posts->num_rows): while($p=$posts->fetch_assoc()): ?>
          <tr data-id="<?= (int)$p['post_id'] ?>">
            <td class="nowrap"><?= (int)$p['post_id'] ?></td>
            <td class="td-clip"><?= e($p['full_name'] ?: $p['username'] ?: 'user_id '.$p['user_id']) ?></td>
            <td class="td-clip"><?= e(mb_strimwidth($p['content'],0,120,'…')) ?></td>
            <td class="nowrap"><?= date('j M Y, H:i', strtotime($p['created_at'])) ?></td>
            <td class="nowrap">
              <button class="btn btn-warning" onclick="editPost(<?= (int)$p['post_id'] ?>)">Edit</button>
              <button class="btn btn-danger" onclick="deletePost(<?= (int)$p['post_id'] ?>)">Delete</button>
            </td>
          </tr>
        <?php endwhile; else: ?><tr><td colspan="5" class="small">No posts found.</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>

  <!-- Likes -->
  <div class="section-title"><span class="emoji">❤️</span> Likes (Latest 20)</div>
  <div class="table-wrap">
    <table>
      <thead><tr><th style="width:70px">ID</th><th>Post (snippet)</th><th>User</th><th>Date</th><th class="nowrap">Action</th></tr></thead>
      <tbody id="likesTable">
        <?php if($likes && $likes instanceof mysqli_result && $likes->num_rows): while($l=$likes->fetch_assoc()): ?>
          <tr data-id="<?= (int)$l['like_id'] ?>">
            <td class="nowrap"><?= (int)$l['like_id'] ?></td>
            <td class="td-clip"><?= e(mb_strimwidth($l['post_content'] ?? '',0,90,'…')) ?></td>
            <td class="td-clip"><?= e($l['liker_name'] ?: 'user_id '.$l['user_id']) ?></td>
            <td class="nowrap"><?= date('j M Y, H:i', strtotime($l['created_at'])) ?></td>
            <td class="nowrap"><button class="btn btn-danger" onclick="deleteLike(<?= (int)$l['like_id'] ?>)">Delete</button></td>
          </tr>
        <?php endwhile; else: ?><tr><td colspan="5" class="small">No likes found.</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>

  <!-- Comments -->
  <div class="section-title"><span class="emoji">💬</span> Comments (Latest 20)</div>
  <div class="table-wrap">
    <table>
      <thead><tr><th style="width:70px">ID</th><th>Post</th><th>User</th><th>Comment</th><th>Date</th><th class="nowrap">Action</th></tr></thead>
      <tbody id="commentsTable">
        <?php if($comments && $comments instanceof mysqli_result && $comments->num_rows): while($c=$comments->fetch_assoc()): ?>
          <tr data-id="<?= (int)$c['comment_id'] ?>">
            <td class="nowrap"><?= (int)$c['comment_id'] ?></td>
            <td class="nowrap">#<?= (int)$c['post_id'] ?></td>
            <td class="td-clip"><?= e($c['commenter_name'] ?: 'user_id '.$c['user_id']) ?></td>
            <td class="td-clip"><?= e(mb_strimwidth($c['comment_text'] ?? '',0,120,'…')) ?></td>
            <td class="nowrap"><?= date('j M Y, H:i', strtotime($c['created_at'])) ?></td>
            <td class="nowrap"><button class="btn btn-danger" onclick="deleteComment(<?= (int)$c['comment_id'] ?>)">Delete</button></td>
          </tr>
        <?php endwhile; else: ?><tr><td colspan="6" class="small">No comments found.</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>

  <!-- Tutors -->
  <div class="section-title"><span class="emoji">🎓</span> Tutors</div>
  <div class="card">
    <form id="addTutorForm" onsubmit="return addTutor(event)" style="margin-bottom:16px">
      <div class="grid grid2">
        <div><label>Tutor Name</label><input type="text" name="tutor_name" required maxlength="120"></div>
        <div><label>Email</label><input type="email" name="email" required maxlength="160"></div>
        <div>
          <label>Year Level</label>
          <select name="year_level" required>
            <option value="Year 2">Year 2</option>
            <option value="Year 3">Year 3</option>
            <option value="Year 4">Year 4</option>
            <option value="Postgraduate">Postgraduate</option>
          </select>
        </div>
        <div><label>Faculty</label><input type="text" name="faculty" required maxlength="160"></div>
        <div><label>Module</label><input type="text" name="module" required maxlength="160"></div>
        <div class="full"><label>Bio</label><textarea name="bio" rows="3" maxlength="600" placeholder="Short description (max 600 chars)"></textarea></div>
      </div>
      <button class="btn btn-primary" type="submit">Add Tutor</button>
    </form>
  </div>

  <div class="table-wrap">
    <table>
      <thead>
        <tr><th style="width:70px">ID</th><th>Tutor</th><th>Email</th><th>Year</th><th>Faculty</th><th>Module</th><th>Updated</th><th class="nowrap">Actions</th></tr>
      </thead>
      <tbody id="tutorTable">
        <?php if($tutors && $tutors instanceof mysqli_result && $tutors->num_rows): while($t=$tutors->fetch_assoc()): ?>
          <tr data-id="<?= (int)$t['id'] ?>">
            <td class="nowrap"><?= (int)$t['id'] ?></td>
            <td class="td-clip"><?= e($t['tutor_name']) ?></td>
            <td class="td-clip"><?= e($t['email']) ?></td>
            <td class="nowrap"><?= e($t['year_level']) ?></td>
            <td class="td-clip"><?= e($t['faculty']) ?></td>
            <td class="td-clip"><?= e($t['module']) ?></td>
            <td class="nowrap"><?= e($t['updated_at']) ?></td>
            <td class="nowrap">
              <button class="btn btn-warning" onclick='editTutor(<?= (int)$t["id"] ?>, <?= json_encode($t, JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_AMP|JSON_HEX_QUOT) ?>)'>Edit</button>
              <button class="btn btn-danger" onclick="deleteTutor(<?= (int)$t['id'] ?>)">Delete</button>
            </td>
          </tr>
        <?php endwhile; else: ?>
          <tr><td colspan="8" class="small">No tutors found.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>

</div>

<script>
// --- Events ---
async function addEvent(e){
  e.preventDefault();
  const f = new FormData(document.getElementById('addEventForm'));
  const r = await fetch('add_event.php',{method:'POST',body:f});
  const d = await r.json(); alert(d.success?'Event added!':d.error||'Error'); if(d.success) location.reload();
}
async function deleteEvent(id){
  if(!confirm('Delete event #'+id+'?'))return;
  const r = await fetch('delete_event.php',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:'id='+id});
  const d = await r.json(); alert(d.success?'Deleted':'Failed'); if(d.success) location.reload();
}
async function editEvent(id){
  const title = prompt('New title:'); if(!title) return;
  const r = await fetch('edit_event.php',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:'id='+id+'&title='+encodeURIComponent(title)});
  const d = await r.json(); alert(d.success?'Updated!':d.error||'Error'); if(d.success) location.reload();
}

// --- Posts ---
async function addPost(e){
  e.preventDefault();
  const f = new FormData(document.getElementById('addPostForm'));
  const r = await fetch('add_post.php',{method:'POST',body:f});
  const d = await r.json(); alert(d.success?'Post added!':d.error||'Error'); if(d.success) location.reload();
}
async function deletePost(id){
  if(!confirm('Delete post #'+id+'?'))return;
  const r = await fetch('delete_post.php',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:'id='+id});
  const d = await r.json(); alert(d.success?'Deleted':'Failed'); if(d.success) location.reload();
}
async function editPost(id){
  const content = prompt('New content:'); if(!content) return;
  const r = await fetch('edit_post.php',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:'id='+id+'&content='+encodeURIComponent(content)});
  const d = await r.json(); alert(d.success?'Updated!':d.error||'Error'); if(d.success) location.reload();
}

// --- Likes / Comments deletes ---
async function deleteLike(id){
  if(!confirm('Delete like #'+id+'?'))return;
  const r = await fetch('delete_like.php',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:'id='+id});
  const d = await r.json(); alert(d.success?'Deleted':'Failed'); if(d.success) location.reload();
}
async function deleteComment(id){
  if(!confirm('Delete comment #'+id+'?'))return;
  const r = await fetch('delete_comment.php',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:'id='+id});
  const d = await r.json(); alert(d.success?'Deleted':'Failed'); if(d.success) location.reload();
}

// --- Tutors ---
async function addTutor(e){
  e.preventDefault();
  const f = new FormData(document.getElementById('addTutorForm'));
  const r = await fetch('add_tutor.php', { method:'POST', body:f });
  const d = await r.json();
  alert(d.success ? 'Tutor added!' : (d.error || 'Failed'));
  if (d.success) location.reload();
}
async function deleteTutor(id){
  if(!confirm('Delete tutor #'+id+'?')) return;
  const r = await fetch('delete_tutor.php', {
    method:'POST',
    headers:{'Content-Type':'application/x-www-form-urlencoded'},
    body:'id='+encodeURIComponent(id)
  });
  const d = await r.json();
  alert(d.success ? 'Deleted' : (d.error || 'Failed'));
  if (d.success) location.reload();
}
async function editTutor(id, row){
  const name = prompt('Tutor name:', row.tutor_name); if(name===null) return;
  const email = prompt('Email:', row.email); if(email===null) return;
  const year  = prompt("Year level (Year 2|Year 3|Year 4|Postgraduate):", row.year_level); if(year===null) return;
  const faculty = prompt('Faculty:', row.faculty); if(faculty===null) return;
  const module  = prompt('Module:', row.module); if(module===null) return;
  const bio     = prompt('Bio (600 chars max):', row.bio ?? ''); if(bio===null) return;

  const body = new URLSearchParams({ id, tutor_name:name, email, year_level:year, faculty, module, bio });
  const r = await fetch('edit_tutor.php', {
    method:'POST',
    headers:{'Content-Type':'application/x-www-form-urlencoded'},
    body: body.toString()
  });
  const d = await r.json();
  alert(d.success ? 'Updated!' : (d.error || 'Failed'));
  if (d.success) location.reload();
}
</script>

<?php $conn->close(); ?>
</body>
</html>