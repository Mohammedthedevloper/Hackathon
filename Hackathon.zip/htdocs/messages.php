<?php
session_start();
include 'db_connection.php';
if(empty($_SESSION['user_id'])) exit();
$currentUserId = $_SESSION['user_id'];

if($_SERVER['REQUEST_METHOD']==='POST'){
    $chatWith = (int)$_POST['chat_with'];
    $message = trim($_POST['message']);
    if($chatWith>0 && $message!==''){
        $stmt = $conn->prepare("INSERT INTO messages (sender_id, receiver_id, message, created_at, is_read) VALUES (?,?,?,?,0)");
        $stmt->bind_param("iiss",$currentUserId,$chatWith,$message,date("Y-m-d H:i:s"));
        $stmt->execute(); $stmt->close();
    }
    exit();
}

$chatWith = isset($_GET['chat_with']) ? (int)$_GET['chat_with'] : 0;
if($chatWith<=0) exit();

// Fetch messages
$stmt = $conn->prepare("SELECT m.*, u.full_name FROM messages m JOIN users u ON m.sender_id=u.user_id WHERE (sender_id=? AND receiver_id=?) OR (sender_id=? AND receiver_id=?) ORDER BY created_at ASC");
$stmt->bind_param("iiii",$currentUserId,$chatWith,$chatWith,$currentUserId);
$stmt->execute();
$messages = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

foreach($messages as $m){
    $cls = ($m['sender_id']==$currentUserId)?'sent':'received';
    echo '<div class="message '.$cls.'">'.htmlspecialchars($m['message']).'<br><small>'.date("H:i",strtotime($m['created_at'])).'</small></div>';
}
?>
