<?php
// admin_dashboard.php — User Analytics (one page, Durban time + sane date fallbacks)

// --- Protect: admins only ---
session_set_cookie_params(['httponly'=>true,'samesite'=>'Lax']);
session_start();
if (!isset($_SESSION['user_id'], $_SESSION['role']) || $_SESSION['role'] !== 'admin') {
  header('Location: login.php'); exit();
}

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// ✅ Set timezone to Durban / South Africa
date_default_timezone_set('Africa/Johannesburg');

include 'db_connection.php';
function e($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }

/** Safely format a datetime string. If NULL/invalid/zero date, use "now" in Durban. */
function safe_fmt($dt, $fmt = 'j M Y, H:i'){
    if (!$dt) return date($fmt);
    $dt = trim((string)$dt);
    if ($dt === '' || $dt === '0000-00-00 00:00:00') return date($fmt);
    $ts = strtotime($dt);
    if ($ts === false || $ts <= 0) return date($fmt);
    return date($fmt, $ts);
}

// ----------------- Fetch data -----------------
$total_users = (int)$conn->query("SELECT COUNT(*) AS c FROM users")->fetch_assoc()['c'];

// Role breakdown
$role_rows = $conn->query("
  SELECT COALESCE(role,'(none)') AS role, COUNT(*) AS c
  FROM users GROUP BY role
");
$roles = ['student'=>0,'lecturer'=>0,'admin'=>0,'(none)'=>0];
while($r = $role_rows->fetch_assoc()){ $roles[$r['role']] = (int)$r['c']; }

// Year-of-major breakdown
$years_rows = $conn->query("
  SELECT COALESCE(year_of_major,'(none)') AS y, COUNT(*) AS c
  FROM users GROUP BY year_of_major ORDER BY c DESC
");
$years = [];
while($y = $years_rows->fetch_assoc()){ $years[$y['y']] = (int)$y['c']; }

// Top majors
$majors_rows = $conn->query("
  SELECT TRIM(majors.major) AS major, majors.c FROM (
    SELECT COALESCE(NULLIF(TRIM(major),''),'(none)') AS major, COUNT(*) AS c
    FROM users GROUP BY major
  ) AS majors
  ORDER BY majors.c DESC, majors.major ASC
  LIMIT 8
");
$majors = [];
while($m = $majors_rows->fetch_assoc()){ $majors[] = $m; }

// Newest users (latest 20)
$latest = $conn->query("
  SELECT user_id, username, full_name, email, role, major, year_of_major, profile_image, created_at
  FROM users ORDER BY created_at DESC, user_id DESC
  LIMIT 20
");

// Most recent join per role (✅ coalesce zero/NULL dates to NOW() so it never shows year -0001)
$recent_by_role = $conn->query("
  SELECT role, MAX(COALESCE(NULLIF(created_at,'0000-00-00 00:00:00'), NOW())) AS last_join
  FROM users GROUP BY role
");
$recentMap = [];
while($rr = $recent_by_role->fetch_assoc()){ $recentMap[$rr['role']] = $rr['last_join']; }

// Helper for % bars
function pct($part, $whole){ return $whole > 0 ? round(($part / $whole) * 100, 1) : 0; }

?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Campus Connect | Admin — User Analytics</title>

<style>
:root{
  --brand:#1e3a8a; --brand-2:#0f2a6a;
  --bg:#0b1220;       /* dark canvas */
  --panel:#0f172a;    /* cards background */
  --panel-2:#0d1526;  /* header/nav background */
  --ink:#e5e7eb;      /* body text */
  --muted:#99a2b8;    /* secondary text */
  --accent:#60a5fa;   /* lines / focus */
  --good:#22c55e; --warn:#f59e0b; --bad:#ef4444;
  --chip:#19233a;     /* badge bg */
  --border:#1e293b;
  --shadow:0 12px 40px rgba(0,0,0,.35);
  --radius:14px;
}

/* Base */
*{box-sizing:border-box}
html,body{height:100%}
body{
  margin:0; font-family: Inter, system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial, sans-serif;
  color:var(--ink); background:
    radial-gradient(1200px 600px at -10% -10%, #1f2a44 0%, transparent 40%),
    radial-gradient(900px 500px at 110% -10%, #132348 0%, transparent 45%),
    radial-gradient(800px 500px at 50% 120%, #16243d 0%, transparent 50%),
    var(--bg);
  -webkit-font-smoothing:antialiased;
}
a{color:inherit; text-decoration:none}

/* Header */
header{
  position:fixed; inset:0 0 auto 0; height:70px; z-index:1000;
  display:flex; align-items:center; justify-content:space-between; gap:14px;
  padding:0 18px; background:linear-gradient(180deg,rgba(13,21,38,.95),rgba(13,21,38,.9));
  border-bottom:1px solid var(--border);
  box-shadow:var(--shadow);
}
.brand{display:flex; align-items:center; gap:12px}
.logo{width:46px;height:46px;border-radius:12px;overflow:hidden;background:var(--brand);display:flex;align-items:center;justify-content:center; box-shadow:0 10px 20px rgba(30,58,138,.35)}
.logo img{width:100%;height:100%;object-fit:cover}
.site-title{font-weight:800;color:#fff;letter-spacing:.2px}
nav{display:flex;align-items:center;gap:10px}
nav a{padding:8px 12px;border-radius:10px;font-weight:600;color:var(--muted);transition:.18s}
nav a:hover, nav a.active{background:rgba(96,165,250,.12); color:#dbeafe}
.logout-form{margin:0}
.logout-btn{
  padding:8px 12px;border:none;border-radius:10px;background:var(--bad);color:#fff;font-weight:700;cursor:pointer;
  box-shadow:0 6px 16px rgba(239,68,68,.28); transition:.18s;
}
.logout-btn:hover{filter:brightness(.96)}

/* Layout */
.container{
  max-width:1200px; margin:0 auto; padding:100px 18px 28px;
  display:flex; flex-direction:column; gap:18px;
}

/* Section headers */
.section-title{
  display:flex; align-items:center; gap:10px; font-weight:800; color:#dbeafe;
  padding:10px 12px; border-radius:12px; background: linear-gradient(180deg, rgba(96,165,250,.14), rgba(96,165,250,.04));
  border:1px solid rgba(96,165,250,.25);
}
.section-title .emoji{font-size:20px}

/* Cards */
.card{
  background: linear-gradient(180deg, rgba(15,23,42,.96), rgba(15,23,42,.92));
  border:1px solid var(--border);
  border-radius:var(--radius); box-shadow:var(--shadow); padding:16px;
}

/* Stats */
.stats{display:grid; grid-template-columns:repeat(5,minmax(0,1fr)); gap:14px}
.stat{
  background:linear-gradient(180deg, #0f1a34, #0c152b);
  border:1px solid var(--border);
  border-radius:16px; padding:16px; text-align:center;
  box-shadow:inset 0 1px 0 rgba(255,255,255,.04), 0 10px 24px rgba(2,6,23,.45);
}
.stat h3{margin:0; font-size:12px; color:var(--muted); letter-spacing:.3px}
.stat p{margin:6px 0 0; font-size:26px; font-weight:900; color:#eaf2ff}
.stat .chip{display:inline-block;margin-top:6px;padding:2px 8px;border-radius:999px;background:var(--chip);color:#bcd3ff;font-size:11px;}

/* Bars */
.bar-row{display:flex; align-items:center; gap:10px; margin:8px 0}
.bar-label{width:140px; color:#cbd5e1; font-size:13px}
.bar{flex:1; height:10px; border-radius:999px; background:#0d1933; overflow:hidden; border:1px solid var(--border)}
.bar > span{display:block; height:100%; background:linear-gradient(90deg,#2a51c5,#60a5fa)}

/* Tables */
.table-wrap{ border-radius:14px; overflow:hidden; border:1px solid var(--border); background:#0c152b }
table{width:100%; border-collapse:separate; border-spacing:0; table-layout:fixed;}
thead th{
  position:sticky; top:0; z-index:1;
  background:linear-gradient(180deg,#0f1b36,#0e1830);
  color:#cbd5e1; letter-spacing:.3px;
  font-weight:900; font-size:12px; padding:12px; text-align:left; border-bottom:1px solid var(--border);
}
tbody tr:nth-child(odd){ background:rgba(255,255,255,.01) }
tbody tr:hover{ background:rgba(96,165,250,.06) }
tbody td{padding:12px; border-bottom:1px solid rgba(255,255,255,.03); vertical-align:top; font-size:14px; color:#e5e7eb}
td.nowrap{white-space:nowrap}
.td-clip{white-space:nowrap; overflow:hidden; text-overflow:ellipsis}

/* Utility */
.search{display:flex; gap:10px; align-items:center; margin-bottom:10px}
.search input{
  flex:1; padding:10px 12px; border-radius:10px; border:1px solid var(--border); background:#0b1326; color:#e5e9f5;
}
.badge{display:inline-block; padding:3px 8px; border-radius:999px; font-size:12px; background:var(--chip); color:#cfe3ff}

/* Responsive */
@media (max-width:1120px){ .stats{grid-template-columns:repeat(3,minmax(0,1fr))} }
@media (max-width:820px){
  .site-title{display:none}
  .stats{grid-template-columns:repeat(2,minmax(0,1fr))}
}
@media (max-width:560px){
  .container{padding-left:14px; padding-right:14px}
  .stats{grid-template-columns:1fr}
}
</style>
</head>
<body>
<header>
  <div class="brand">
    <div class="logo"><img src="images/logo.jpg" alt="Logo"></div>
    <span class="site-title">Campus Connect — Admin</span>
  </div>
  <nav>
    <a href="admin_content_dashboard.php">Content</a>
    <a href="admin_dashboard.php" class="active">Users</a>
    <form action="logout.php" method="post" class="logout-form">
      <button type="submit" class="logout-btn">Logout</button>
    </form>
  </nav>
</header>

<div class="container">

  <!-- Top stats -->
  <div class="stats">
    <div class="stat"><h3>Total Users</h3><p><?= $total_users ?></p><span class="chip">All roles</span></div>
    <div class="stat"><h3>Students</h3><p><?= (int)$roles['student'] ?></p><span class="chip"><?= pct($roles['student'],$total_users) ?>%</span></div>
    <div class="stat"><h3>Lecturers</h3><p><?= (int)$roles['lecturer'] ?></p><span class="chip"><?= pct($roles['lecturer'],$total_users) ?>%</span></div>
    <div class="stat"><h3>Admins</h3><p><?= (int)$roles['admin'] ?></p><span class="chip"><?= pct($roles['admin'],$total_users) ?>%</span></div>
    <div class="stat"><h3>Unassigned</h3><p><?= (int)$roles['(none)'] ?></p><span class="chip"><?= pct($roles['(none)'],$total_users) ?>%</span></div>
  </div>

  <!-- Role distribution bars -->
  <div class="section-title"><span class="emoji">📊</span> Role Distribution</div>
  <div class="card">
    <?php foreach (['student','lecturer','admin','(none)'] as $r): ?>
      <div class="bar-row">
        <div class="bar-label"><?= ucfirst($r) ?></div>
        <div class="bar"><span style="width:<?= pct($roles[$r],$total_users) ?>%"></span></div>
        <div class="badge"><?= $roles[$r] ?> (<?= pct($roles[$r],$total_users) ?>%)</div>
      </div>
    <?php endforeach; ?>
  </div>

  <!-- Year-of-major -->
  <div class="section-title"><span class="emoji">🎓</span> Year of Major</div>
  <div class="card">
    <?php foreach ($years as $label => $count): ?>
      <div class="bar-row">
        <div class="bar-label"><?= e($label) ?></div>
        <div class="bar"><span style="width:<?= pct($count,$total_users) ?>%"></span></div>
        <div class="badge"><?= $count ?> (<?= pct($count,$total_users) ?>%)</div>
      </div>
    <?php endforeach; ?>
  </div>

  <!-- Top majors -->
  <div class="section-title"><span class="emoji">🏷️</span> Top Majors</div>
  <div class="card">
    <?php if (count($majors)): foreach ($majors as $m): ?>
      <div class="bar-row">
        <div class="bar-label"><?= e($m['major']) ?></div>
        <div class="bar"><span style="width:<?= pct((int)$m['c'],$total_users) ?>%"></span></div>
        <div class="badge"><?= (int)$m['c'] ?> (<?= pct((int)$m['c'],$total_users) ?>%)</div>
      </div>
    <?php endforeach; else: ?>
      <div class="small">No major data yet.</div>
    <?php endif; ?>
  </div>

  <!-- Latest users -->
  <div class="section-title"><span class="emoji">🧑‍🤝‍🧑</span> Latest Users (20)</div>
  <div class="card">
    <div class="search">
      <input type="text" id="userSearch" placeholder="Search name, username, email, role, major…">
      <span class="small">Tip: type “role:student” or “year:Year 2”</span>
    </div>
    <div class="table-wrap">
      <table id="usersTable">
        <thead>
          <tr>
            <th style="width:70px">ID</th>
            <th style="width:56px">Pic</th>
            <th>Name</th>
            <th>Username</th>
            <th>Email</th>
            <th style="width:110px">Role</th>
            <th>Major</th>
            <th style="width:120px">Year</th>
            <th style="width:170px">Joined</th>
          </tr>
        </thead>
        <tbody>
        <?php if ($latest && $latest->num_rows): while($u = $latest->fetch_assoc()): ?>
          <tr>
            <td class="nowrap"><?= (int)$u['user_id'] ?></td>
            <td class="nowrap">
              <?php if(!empty($u['profile_image'])): ?>
                <img src="images/<?= e($u['profile_image']) ?>" alt="" style="width:36px;height:36px;border-radius:8px;object-fit:cover;border:1px solid var(--border)">
              <?php else: ?>
                <div style="width:36px;height:36px;border-radius:8px;display:flex;align-items:center;justify-content:center;background:#0e1a35;color:#cfe3ff;font-weight:900">
                  <?= strtoupper(substr($u['full_name'] ?: $u['username'],0,1)) ?>
                </div>
              <?php endif; ?>
            </td>
            <td class="td-clip" title="<?= e($u['full_name']) ?>"><?= e($u['full_name'] ?: '—') ?></td>
            <td class="td-clip" title="<?= e($u['username']) ?>"><?= e($u['username']) ?></td>
            <td class="td-clip" title="<?= e($u['email']) ?>"><?= e($u['email']) ?></td>
            <td class="nowrap"><span class="badge"><?= e($u['role'] ?: '(none)') ?></span></td>
            <td class="td-clip" title="<?= e($u['major']) ?>"><?= e($u['major'] ?: '—') ?></td>
            <td class="nowrap"><?= e($u['year_of_major'] ?: '—') ?></td>
            <td class="nowrap"><?= safe_fmt($u['created_at']) ?></td>
          </tr>
        <?php endwhile; else: ?>
          <tr><td colspan="9" class="small">No users found.</td></tr>
        <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>

  <!-- Recent join per role -->
  <div class="section-title"><span class="emoji">⏱️</span> Most Recent Join (by role)</div>
  <div class="card">
    <div style="display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px">
      <?php foreach(['student','lecturer','admin','(none)'] as $r): ?>
        <div class="stat" style="padding:14px">
          <h3 style="text-transform:capitalize"><?= $r ?></h3>
          <p style="font-size:18px;margin:8px 0 0">
            <?= isset($recentMap[$r]) ? safe_fmt($recentMap[$r]) : safe_fmt(null) ?>
          </p>
        </div>
      <?php endforeach; ?>
    </div>
  </div>

</div>

<script>
// Simple client-side filtering for Latest Users table
const q = document.getElementById('userSearch');
const rows = Array.from(document.querySelectorAll('#usersTable tbody tr'));

q.addEventListener('input', () => {
  const v = q.value.trim().toLowerCase();

  rows.forEach(tr => {
    const text = tr.innerText.toLowerCase();
    // advanced: role:student / year:Year 2 filters
    let keep = true;
    if (v.includes('role:')) {
      const role = v.split('role:')[1].split(' ')[0].trim();
      keep = tr.innerText.toLowerCase().includes(role);
    }
    if (v.includes('year:')) {
      const y = v.split('year:')[1].split(' ')[0].trim();
      keep = keep && tr.innerText.toLowerCase().includes(y);
    }
    if (!v.includes('role:') && !v.includes('year:')) {
      keep = text.includes(v);
    }
    tr.style.display = keep ? '' : 'none';
  });
});
</script>

<?php $conn->close(); ?>
</body>
</html>