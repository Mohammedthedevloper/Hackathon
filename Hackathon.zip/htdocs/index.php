<?php
// index.php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
include 'db_connection.php';

// Helper to escape output
function e($s) { return htmlspecialchars($s ?? '', ENT_QUOTES, 'UTF-8'); }

// Redirect to login if not logged in
if (empty($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Current user
$currentUserId = $_SESSION['user_id'];
$currentUser = null;
$stmt = $conn->prepare("SELECT user_id, username, full_name, profile_image FROM users WHERE user_id = ?");
$stmt->bind_param("i", $currentUserId);
$stmt->execute();
$currentUser = $stmt->get_result()->fetch_assoc();
$stmt->close();

// ---------- Handle POST actions (likes, comments, logout) ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Toggle Like
    if (isset($_POST['like_post_id'])) {
        $postId = (int)$_POST['like_post_id'];
        $chk = $conn->prepare("SELECT like_id FROM likes WHERE post_id = ? AND user_id = ?");
        $chk->bind_param("ii", $postId, $currentUserId);
        $chk->execute();
        $res = $chk->get_result();
        if ($res->num_rows > 0) {
            $del = $conn->prepare("DELETE FROM likes WHERE post_id = ? AND user_id = ?");
            $del->bind_param("ii", $postId, $currentUserId);
            $del->execute();
            $del->close();
        } else {
            $ins = $conn->prepare("INSERT INTO likes (post_id, user_id) VALUES (?, ?)");
            $ins->bind_param("ii", $postId, $currentUserId);
            $ins->execute();
            $ins->close();
        }
        $chk->close();
        header("Location: " . $_SERVER['PHP_SELF'] . "#post-" . $postId);
        exit();
    }

    // Add comment
    if (isset($_POST['comment_post_id']) && isset($_POST['comment_text'])) {
        $postId = (int)$_POST['comment_post_id'];
        $commentText = trim($_POST['comment_text']);
        if ($commentText !== '') {
            $stmt = $conn->prepare("INSERT INTO comments (post_id, user_id, comment_text) VALUES (?, ?, ?)");
            $stmt->bind_param("iis", $postId, $currentUserId, $commentText);
            $stmt->execute();
            $stmt->close();
        }
        header("Location: " . $_SERVER['PHP_SELF'] . "#post-" . $postId);
        exit();
    }

    // Logout
    if (isset($_POST['action']) && $_POST['action'] === 'logout') {
        session_unset();
        session_destroy();
        header("Location: login.php");
        exit();
    }
}

// ---------- Fetch posts ----------
$posts_sql = "
    SELECT p.post_id, p.content, p.image, p.created_at,
           u.full_name AS author, u.username, u.profile_image, p.user_id AS author_id
    FROM posts p
    JOIN users u ON p.user_id = u.user_id
    ORDER BY p.created_at DESC
    LIMIT 50
";
$posts_result = $conn->query($posts_sql);

// ---------- Fetch upcoming events ----------
$events_sql = "
    SELECT event_id, title, date_time, image
    FROM events
    WHERE date_time >= NOW()  -- only future events
    ORDER BY date_time ASC
    LIMIT 3
";
$events_result = $conn->query($events_sql);


// ---------- Personal stats ----------
$my_posts = (int) $conn->query("SELECT COUNT(*) AS cnt FROM posts WHERE user_id = " . (int)$currentUserId)->fetch_assoc()['cnt'];
$total_posts = (int) $conn->query("SELECT COUNT(*) AS cnt FROM posts")->fetch_assoc()['cnt'];
$total_events = (int) $conn->query("SELECT COUNT(*) AS cnt FROM events")->fetch_assoc()['cnt'];
$total_users = (int) $conn->query("SELECT COUNT(*) AS cnt FROM users")->fetch_assoc()['cnt'];

?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width,initial-scale=1" />
<title>Campus Connect | Home</title>

<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700&display=swap" rel="stylesheet">

<style>
:root{
  --primary: #1e3a8a;
  --muted: #6b7280;
  --bg: #f7f8fb;
  --card: #ffffff;
  --glass: rgba(255,255,255,0.75);
  --radius: 12px;
  --shadow: 0 10px 30px rgba(2,6,23,0.08);
}
*{box-sizing:border-box}
body{margin:0;font-family:'Inter',system-ui,-apple-system,'Segoe UI',Roboto,"Helvetica Neue",Arial;color:#0f172a;background:var(--bg);-webkit-font-smoothing:antialiased}
a{color:inherit;text-decoration:none}

/* Header: fixed at top always */
header{
  position:fixed; top:0; left:0; right:0; height:68px;
  display:flex; align-items:center; padding:0 22px; gap:16px;
  z-index:1200;
  background: linear-gradient(180deg, rgba(255,255,255,0.98), rgba(255,255,255,0.96));
  box-shadow: 0 8px 30px rgba(2,6,23,0.08);
  backdrop-filter: blur(6px);
}

/* brand left */
.brand { display:flex; align-items:center; gap:12px; }
.logo { width:52px; height:52px; border-radius:10px; overflow:hidden; background:var(--primary); display:flex; align-items:center; justify-content:center; }
.logo img { width:100%; height:100%; object-fit:cover; }
.site-title { font-weight:700; color:var(--primary); font-size:18px; }

/* nav to right */
nav { margin-left:auto; display:flex; align-items:center; gap:10px; }
nav a { padding:8px 12px; border-radius:10px; color:var(--muted); font-weight:600; transition: all .18s; }
nav a.active, nav a:hover { background: rgba(30,58,138,0.08); color:var(--primary); }

/* logout form button inside nav */
.logout-btn{ padding:8px 12px; border-radius:8px; border:none; background:#ef4444; color:#fff; font-weight:600; cursor:pointer; transition:background .18s; }
.logout-btn:hover{ background:#dc2626; }

/* HERO */
.hero{
  height:100vh; width:100%;
  background: url('images/durban_eduvos.jpg') center/cover no-repeat;
  display:flex; align-items:center; justify-content:center; position:relative; color:#fff; text-align:center; padding:0 20px;
}
.hero::after{ content:""; position:absolute; inset:0; background:linear-gradient(180deg, rgba(2,6,23,0.45), rgba(2,6,23,0.18)); }
.hero-inner { position:relative; z-index:2; max-width:980px; }
.hero h1{ margin:0; font-size:44px; font-weight:800; letter-spacing:-0.01em; }
.hero p{ margin-top:10px; color:rgba(255,255,255,0.92); font-size:18px; }
.hero .scroll-btn{ margin-top:22px; background:transparent; border:2px solid #fff; color:#fff; padding:10px 20px; border-radius:999px; font-weight:700; cursor:pointer; transition:all .22s }
.hero .scroll-btn:hover{ background:#fff; color:var(--primary); transform:translateY(-3px); }

/* main layout */
main.container{ max-width:1200px; margin:0 auto; padding:24px; display:flex; gap:22px; align-items:flex-start; padding-top:92px; }
.main{ flex:3; display:flex; flex-direction:column; gap:18px; }
aside{ flex:1; display:flex; flex-direction:column; gap:16px; position:sticky; top:92px; }

/* cards */
.card{ background:var(--card); border-radius:var(--radius); padding:14px; box-shadow:var(--shadow); border:1px solid rgba(2,6,23,0.04); }
.card:hover{ transform: translateY(-3px); transition:transform .18s; }

/* welcome */
.welcome-card{ display:flex; align-items:center; gap:14px; }
.welcome-card img{ width:84px; height:84px; border-radius:14px; object-fit:cover; border:3px solid var(--primary); }
.welcome-text h2{ margin:0; font-size:20px; }
.welcome-text p{ margin:6px 0 0; color:var(--muted); }

/* composer simplified */
.actions-row{ display:flex; gap:10px; margin-top:12px; }
.btn-primary{ background:var(--primary); color:#fff; border:none; padding:10px 14px; border-radius:10px; font-weight:700; cursor:pointer; }
.btn-outline{ background:#fff; border:1px solid rgba(2,6,23,0.06); color:var(--primary); padding:10px 14px; border-radius:10px; font-weight:700; cursor:pointer; }

/* feed posts */
.post{ padding:16px; border-radius:12px; background:linear-gradient(180deg,#fff,#fbfdff); }
.post-header{ display:flex; gap:12px; align-items:center; margin-bottom:8px; }
.post-header .avatar{ width:56px; height:56px; border-radius:10px; overflow:hidden; background:#f1f5f9; display:flex; align-items:center; justify-content:center; font-weight:700; color:#0b1220; }
.post-header .meta{ flex:1; }
.post-content p{ margin:0; color:#0b1220; line-height:1.5; }
.post-image{ width:100%; margin-top:10px; border-radius:10px; object-fit:cover; max-height:420px; }

/* action buttons */
.actions { display:flex; gap:10px; align-items:center; margin-top:12px; }
.actions form{ display:inline; }
.like-btn, .comment-btn{ display:inline-flex; align-items:center; gap:8px; padding:8px 12px; border-radius:999px; cursor:pointer; border:1px solid transparent; font-weight:700; background:transparent; }
.like-btn{ color:#ef4444; }
.like-btn:hover{ background:rgba(255,230,230,0.95); }
.comment-btn{ color:var(--primary); }
.comment-btn:hover{ background:rgba(219,234,254,0.95); }

/* comments */
.comment{ margin-top:12px; padding:10px; background:#f8fafc; border-radius:10px; }

/* sidebar events */
.event-card{ display:flex; gap:12px; align-items:center; padding:10px; border-radius:12px; background:white; box-shadow:0 6px 20px rgba(2,6,23,0.04); cursor:pointer; transition:transform .18s; }
.event-card img{ width:72px; height:72px; object-fit:cover; border-radius:8px; }
.event-card:hover{ transform:translateX(5px); }

/* stats */
.stats-tile { display:flex; flex-direction:column; gap:6px; padding:14px; border-radius:12px; background:linear-gradient(180deg,#fff,#fbfdff); }

/* bottom-right post CTA in sidebar */
.post-cta { display:block; text-align:center; padding:12px 14px; border-radius:12px; background:linear-gradient(135deg,var(--primary), #2563eb); color:white; font-weight:700; cursor:pointer; box-shadow:0 10px 30px rgba(46,64,153,0.18); }

/* small screens */
@media(max-width:980px){
  .hero h1{ font-size:32px; }
  main.container{ flex-direction:column; padding:18px; }
  aside{ position:relative; top:0; }
  nav{ gap:6px; }
}
</style>
</head>
<body>

<header id="pageHeader">
  <div class="brand">
    <div class="logo"><img src="images/logo.jpg" alt="Logo"></div>
    <span class="site-title">Campus Connect</span>
  </div>

  <nav>
    <a href="index.php" class="active">Home</a>
    <a href="about.php">About</a>
    <a href="profile.php">Profile</a>
    <a href="events.php">Events</a>
    <a href="plug.php">Plug In | Tutor Board</a>

    <form method="POST" style="display:inline;margin-left:6px;">
        <input type="hidden" name="action" value="logout">
        <button type="submit" class="logout-btn">Logout</button>
    </form>
  </nav>
</header>

<section class="hero" role="banner" aria-label="Campus hero">
  <div class="hero-inner">
    <h1>Welcome to Campus Connect</h1>
    <p>Your digital campus hub — post, connect, and stay informed.</p>
    <div style="margin-top:18px;">
      <button class="scroll-btn" id="scrollToFeed">Explore Feed ↓</button>
    </div>
  </div>
</section>

<main class="container" id="feed">
  <div class="main">
    <div class="card welcome-card" style="align-items:flex-start;">
      <?php if(!empty($currentUser['profile_image'])): ?>
        <img src="images/<?php echo e($currentUser['profile_image']); ?>" alt="Profile">
      <?php else: ?>
        <div class="avatar" style="width:84px;height:84px;border-radius:14px;font-size:28px;display:flex;align-items:center;justify-content:center;background:#eef2ff;color:var(--primary)"><?php echo e(strtoupper(substr($currentUser['full_name'],0,1))); ?></div>
      <?php endif; ?>
      <div class="welcome-text" style="flex:1;">
        <h2>Welcome, <?php echo e($currentUser['full_name']); ?>!</h2>
        <p>Share updates with your campus — or scroll to see the latest posts from your peers.</p>

        <div class="actions-row" style="margin-top:12px;">
          <button class="btn-primary" onclick="window.location.href='post.php'">📝 Post Update</button>
          <button class="btn-outline" onclick="document.getElementById('feed').scrollIntoView({behavior:'smooth'})">Explore Feed</button>
        </div>
      </div>
    </div>

    <div style="display:flex;justify-content:space-between;align-items:center">
      <h3 style="margin:0">Campus Feed</h3>
      <small style="color:var(--muted)"><?php echo (int)$total_posts; ?> posts • <?php echo (int)$total_events; ?> events</small>
    </div>

    <!-- posts loop -->
    <?php if ($posts_result && $posts_result->num_rows > 0): ?>
      <?php while ($p = $posts_result->fetch_assoc()): ?>
        <?php
          $stmtL = $conn->prepare("SELECT COUNT(*) as cnt FROM likes WHERE post_id = ?");
          $stmtL->bind_param("i", $p['post_id']); $stmtL->execute();
          $likesCount = $stmtL->get_result()->fetch_assoc()['cnt']; $stmtL->close();

          $stmtUL = $conn->prepare("SELECT like_id FROM likes WHERE post_id = ? AND user_id = ?");
          $stmtUL->bind_param("ii",$p['post_id'],$currentUserId); $stmtUL->execute();
          $userLiked = ($stmtUL->get_result()->num_rows>0); $stmtUL->close();

          $stmtC = $conn->prepare("
            SELECT c.comment_id, c.comment_text, c.created_at, u.username, u.full_name
            FROM comments c JOIN users u ON c.user_id=u.user_id
            WHERE c.post_id = ? ORDER BY c.created_at ASC
          ");
          $stmtC->bind_param("i",$p['post_id']); $stmtC->execute();
          $commentsRes = $stmtC->get_result(); $stmtC->close();
        ?>
        <article id="post-<?php echo (int)$p['post_id']; ?>" class="card post">
          <div class="post-header">
            <div class="avatar">
              <?php if(!empty($p['profile_image'])): ?>
                <img src="images/<?php echo e($p['profile_image']); ?>" alt="Avatar" style="width:56px;height:56px;object-fit:cover;border-radius:10px">
              <?php else: ?>
                <?php echo e(strtoupper(substr($p['author'] ?: $p['username'],0,1))); ?>
              <?php endif; ?>
            </div>
            <div class="meta">
              <div style="font-weight:700;color:#0b1220"><?php echo e($p['author'] ?: $p['username']); ?></div>
              <div style="color:var(--muted);font-size:13px"><?php echo date("M j, Y g:i a", strtotime($p['created_at'])); ?></div>
            </div>
          </div>

          <div class="post-content">
            <p><?php echo nl2br(e($p['content'])); ?></p>
            <?php if(!empty($p['image'])): ?>
              <img src="images/<?php echo e($p['image']); ?>" class="post-image" alt="Post image">
            <?php endif; ?>
          </div>

          <div class="actions">
            <form method="POST">
              <input type="hidden" name="like_post_id" value="<?php echo (int)$p['post_id']; ?>">
              <button type="submit" class="like-btn"><?php echo $userLiked ? '❤️' : '🤍'; ?> <?php echo $likesCount; ?></button>
            </form>

            <form method="POST">
              <input type="hidden" name="comment_post_id" value="<?php echo (int)$p['post_id']; ?>">
              <input type="text" name="comment_text" placeholder="Comment..." style="padding:8px 12px;border-radius:10px;border:1px solid #ddd;width:100%;max-width:200px">
              <button type="submit" class="comment-btn">Post</button>
            </form>
          </div>

          <?php if($commentsRes && $commentsRes->num_rows>0): ?>
            <?php while($c = $commentsRes->fetch_assoc()): ?>
              <div class="comment"><strong><?php echo e($c['full_name']); ?>:</strong> <?php echo e($c['comment_text']); ?></div>
            <?php endwhile; ?>
          <?php endif; ?>
        </article>
      <?php endwhile; ?>
    <?php else: ?>
      <p>No posts yet. Be the first to share!</p>
    <?php endif; ?>

  </div>

  <aside>
    <div class="card stats-tile">
      <h4>My Stats</h4>
      <p>Posts: <?php echo (int)$my_posts; ?></p>
      <p>Total Users: <?php echo (int)$total_users; ?></p>
      <p>Total Posts: <?php echo (int)$total_posts; ?></p>
      <p>Total Events: <?php echo (int)$total_events; ?></p>
    </div>

    <div class="card">
      <h4>Upcoming Events</h4>
      <?php if($events_result && $events_result->num_rows>0): ?>
        <?php while($ev = $events_result->fetch_assoc()): ?>
          <div class="event-card">
            <?php if(!empty($ev['image'])): ?><img src="images/<?php echo e($ev['image']); ?>" alt="Event"><?php endif; ?>
            <div>
              <strong><?php echo e($ev['title']); ?></strong><br>
              <small style="color:var(--muted)"><?php echo date("M j, Y g:i a", strtotime($ev['date_time'])); ?></small>
            </div>
          </div>
        <?php endwhile; ?>
      <?php else: ?>
        <p>No upcoming events</p>
      <?php endif; ?>
    </div>

    <div class="post-cta" onclick="window.location.href='post.php'">Post an Update</div>
  </aside>
</main>

<script>
// smooth scroll hero button
document.getElementById('scrollToFeed').addEventListener('click',function(){
  document.getElementById('feed').scrollIntoView({behavior:'smooth'});
});
</script>

</body
