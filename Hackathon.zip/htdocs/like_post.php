<?php
session_start();
include 'db_connection.php';
if(!isset($_SESSION['user_id']) || !isset($_POST['post_id'])) { header("Location: index.php"); exit; }

$userId = $_SESSION['user_id'];
$postId = intval($_POST['post_id']);

// Toggle like
$check = $conn->query("SELECT * FROM likes WHERE user_id=$userId AND post_id=$postId");
if($check->num_rows > 0) {
    $conn->query("DELETE FROM likes WHERE user_id=$userId AND post_id=$postId");
} else {
    $conn->query("INSERT INTO likes (user_id, post_id) VALUES ($userId, $postId)");
}

header("Location: index.php");
exit;
