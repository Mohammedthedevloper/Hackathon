<?php
// tutor_messaging.php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
include 'db_connection.php';

// Check if user is logged in
if(empty($_SESSION['user_id'])){
    header("Location: login.php");
    exit();
}

$currentUserId = $_SESSION['user_id'];
$toUserId = isset($_GET['to']) ? (int)$_GET['to'] : 0;

if($toUserId==0){
    die("Invalid tutor selected.");
}

// ✅ Mark all messages from this tutor as read
$stmt = $conn->prepare("UPDATE messages SET is_read = 1 WHERE sender_id = ? AND receiver_id = ?");
$stmt->bind_param("ii", $toUserId, $currentUserId);
$stmt->execute();
$stmt->close();

// ✅ Fetch tutor info
$stmt = $conn->prepare("SELECT tutor_name FROM tutors WHERE user_id=?");
$stmt->bind_param("i", $toUserId);
$stmt->execute();
$tutor = $stmt->get_result()->fetch_assoc();
$stmt->close();

// ✅ Send a new message
if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['message'])){
    $msg = trim($_POST['message']);
    if($msg!==''){
        $stmt = $conn->prepare("INSERT INTO messages (sender_id, receiver_id, message, created_at) VALUES (?,?,?,NOW())");
        $stmt->bind_param("iis", $currentUserId, $toUserId, $msg);
        $stmt->execute();
        $stmt->close();

        // Redirect to avoid form resubmission
        header("Location: tutor_messaging.php?to=$toUserId");
        exit();
    }
}

// ✅ Fetch all messages in this conversation
$stmt = $conn->prepare("
    SELECT m.*, u.full_name as sender_name
    FROM messages m
    LEFT JOIN users u ON m.sender_id=u.user_id
    WHERE (m.sender_id=? AND m.receiver_id=?) OR (m.sender_id=? AND m.receiver_id=?)
    ORDER BY m.created_at ASC
");
$stmt->bind_param("iiii", $currentUserId, $toUserId, $toUserId, $currentUserId);
$stmt->execute();
$messages = $stmt->get_result();
$stmt->close();
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<title>Chat with <?php echo htmlspecialchars($tutor['tutor_name']); ?></title>
<style>
body {
    font-family: 'Inter', sans-serif;
    background: #f7f8fb;
    margin: 0;
    padding: 0;
    display: flex;
    flex-direction: column;
    height: 100vh;
}
header {
    background: #1e3a8a;
    color: #fff;
    padding: 12px;
    font-size: 18px;
    font-weight: 600;
}
main {
    flex: 1;
    overflow-y: auto;
    padding: 12px;
    display: flex;
    flex-direction: column;
    gap: 8px;
}
.message {
    padding: 8px 12px;
    border-radius: 12px;
    max-width: 60%;
    background: #fff;
    box-shadow: 0 2px 5px rgba(0,0,0,0.1);
}
.message.me {
    background: #1e3a8a;
    color: #fff;
    align-self: flex-end;
}
form {
    display: flex;
    gap: 8px;
    padding: 12px;
    border-top: 1px solid #ddd;
    background: #fff;
}
form input {
    flex: 1;
    padding: 8px 12px;
    border-radius: 12px;
    border: 1px solid #ddd;
}
form button {
    padding: 8px 12px;
    border: none;
    border-radius: 12px;
    background: #1e3a8a;
    color: #fff;
    cursor: pointer;
}
</style>
</head>
<body>

<header>Chat with <?php echo htmlspecialchars($tutor['tutor_name']); ?></header>

<main>
    <?php while($m = $messages->fetch_assoc()): ?>
        <div class="message <?php echo ($m['sender_id'] == $currentUserId) ? 'me' : ''; ?>">
            <strong><?php echo htmlspecialchars($m['sender_name']); ?>:</strong> <?php echo htmlspecialchars($m['message']); ?>
        </div>
    <?php endwhile; ?>
</main>

<form method="POST">
    <input type="text" name="message" placeholder="Type your message..." required>
    <button type="submit">Send</button>
</form>

</body>
</html>
