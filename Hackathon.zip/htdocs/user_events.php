<?php
session_set_cookie_params(['httponly'=>true,'samesite'=>'Lax']);
session_start();
header('Content-Type: application/json');

require 'db_connection.php';

$userId = $_SESSION['user_id'] ?? null;
if (!$userId) { echo json_encode([]); exit; }

// Only this user's events
$sql = "SELECT event_id, title, date_time, description, location
        FROM events
        WHERE created_by = ?
        ORDER BY date_time ASC";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $userId);
$stmt->execute();
$res = $stmt->get_result();

$out = [];
while ($r = $res->fetch_assoc()) {
  $out[] = [
    'id'          => (string)$r['event_id'],
    'title'       => $r['title'],
    'start'       => $r['date_time'],
    'description' => $r['description'],
    'location'    => $r['location'],
  ];
}
echo json_encode($out);