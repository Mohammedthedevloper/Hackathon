<?php  
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
include 'db_connection.php';

// Check if user is logged in
$currentUserId = $_SESSION['user_id'] ?? null;
$currentUser = null;
if ($currentUserId) {
    $stmt = $conn->prepare("SELECT user_id, username, full_name, profile_image FROM users WHERE user_id = ?");
    $stmt->bind_param("i", $currentUserId);
    $stmt->execute();
    $currentUser = $stmt->get_result()->fetch_assoc();
    $stmt->close();
}

// Handle logout
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'logout') {
    session_unset();
    session_destroy();
    header("Location: events.php");
    exit();
}

// Handle event submission
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['title']) && $currentUser) {
    $title = $conn->real_escape_string($_POST['title']);
    $description = $conn->real_escape_string($_POST['description']);
    $date_time = $conn->real_escape_string($_POST['date_time']);
    $location = $conn->real_escape_string($_POST['location']);
    $created_by = $currentUserId;

    // Handle image upload
    $imagePath = "";
    if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $targetDir = "images/";
        $fileName = time() . "_" . basename($_FILES["image"]["name"]);
        $targetFile = $targetDir . $fileName;
        if (move_uploaded_file($_FILES["image"]["tmp_name"], $targetFile)) {
            $imagePath = $fileName;
        }
    }

    // Insert into DB
    $sql = "INSERT INTO events (title, description, date_time, location, image, created_by) 
            VALUES ('$title', '$description', '$date_time', '$location', '$imagePath', '$created_by')";
    if (!$conn->query($sql)) {
        echo "Error: " . $conn->error;
    }
}

// Fetch all events
$result = $conn->query("SELECT * FROM events ORDER BY date_time ASC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Campus Connect - Events</title>
<link rel="stylesheet" href="events.css"> 
<style>
body { 
  margin:0; 
  padding:0; 
  font-family:sans-serif; 
  background:#f9fafb; 
  color:#111827; 
}
a { text-decoration:none; color:inherit; }

/* Header */
header {
  position:fixed; top:0; left:0; right:0; height:60px;
  background:#fff; display:flex; align-items:center; justify-content:space-between;
  padding:0 20px; box-shadow:0 6px 18px rgba(0,0,0,0.08); z-index:1000;
}
.brand { display:flex; align-items:center; gap:12px; }
.logo { width:48px; height:48px; border-radius:8px; overflow:hidden; background:#1e3a8a; display:flex; align-items:center; justify-content:center; }
.logo img { width:100%; height:100%; object-fit:cover; }
.site-title { font-weight:700; font-size:20px; color:#1e3a8a; }
nav { display:flex; gap:12px; align-items:center; }
nav a { padding:8px 14px; border-radius:8px; font-weight:600; color:#6b7280; transition:0.2s; }
nav a.active, nav a:hover { background:rgba(30,58,138,0.1); color:#1e3a8a; }

.login-btn, .signup-btn, .logout-btn {
  padding:8px 16px; border-radius:8px; border:none; font-weight:600; cursor:pointer; transition:0.2s;
}
.login-btn { background:white; color:#1e3a8a; border:1px solid #1e3a8a; }
.login-btn:hover { background:#1e3a8a; color:white; }
.signup-btn { background:#1e3a8a; color:white; }
.signup-btn:hover { background:#153e75; }
.logout-btn { background:#ef4444; color:#fff; border:1px solid #ef4444; }
.logout-btn:hover { background:#dc2626; }

.user-info { display:flex; align-items:center; gap:8px; }
.user-avatar {
  width:32px; height:32px; border-radius:50%; overflow:hidden;
  background:#e5e7eb; display:flex; align-items:center; justify-content:center; font-weight:bold; color:#1f2937;
}
.user-avatar img { width:100%; height:100%; object-fit:cover; }

/* Containers */
.main-container {
  display: flex;
  gap: 30px; 
  padding: 80px 40px; 
  justify-content: center;
  align-items: flex-start;
  flex-wrap: wrap;
  max-width: 1400px; 
  margin: 0 auto;
  box-sizing: border-box;
}


/* Event Grid */
.events-grid {
  display: grid;
   gap: 20px;
  flex: 1 1 700px;
  width: 100%;
  justify-items: center;
  align-content: start;
}

/* When user is logged in: exactly 3 per row */
.logged-in .events-grid {
  grid-template-columns: repeat(3, minmax(250px, 1fr));
}

/* When user is not logged in: make it auto-fit as before */
.logged-out .events-grid {
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
}

/* Event Cards */
.event-card {
  width: 100%;
  max-width: 300px;
  text-align: center;
  border: 1px solid #ddd;
  border-radius: 8px;
  padding: 10px;
  background: white;
  box-sizing: border-box;
}

/* Sidebar */
.sidebar {
  width: 300px;
  min-width: 280px;
  background: white;
  border: 1px solid #ddd;
  border-radius: 8px;
  padding: 15px;
  box-sizing: border-box;
}

.sidebar form input, 
.sidebar form textarea, 
.sidebar form button { 
  display:block; 
  width:100%; 
  margin-bottom:10px; 
  padding:8px; 
  border-radius:6px; 
  border:1px solid #ccc; 
}

.sidebar form button { 
  background:#1e3a8a; 
  color:white; 
  border:none; 
  cursor:pointer; 
}

.sidebar form button:hover { 
  background:#153e75; 
}
    .calender-btn {
    background-color: #10b981; /* Tailwind green-500 */
    color: white;
    border: none;
    border-radius: 8px;
    padding: 8px 12px;
    font-weight: 600;
    cursor: pointer;
    transition: background 0.2s;
}

.calender-btn:hover {
    background-color: #059669; /* Tailwind green-600 */
}

</style>
</head>
<body class="<?php echo $currentUser ? 'logged-in' : 'logged-out'; ?>">

<header>
  <div class="brand">
    <div class="logo"><img src="images/logo.jpg" alt="Logo"></div>
    <span class="site-title">Campus Connect</span>
  </div>

  <nav>
    <a href="index.php">Home</a>
    <a href="about.php">About</a>
    <a href="profile.php">Profile</a>
    <a href="events.php" class="active">Events</a>
    <a href="tutorship.php">Tutorship</a>
    <a href="messaging.php">Chats</a>

    <?php if ($currentUser): ?>
      <div class="user-info">
        <div class="user-avatar">
          <?php if (!empty($currentUser['profile_image'])): ?>
            <img src="images/<?php echo htmlspecialchars($currentUser['profile_image']); ?>" alt="Avatar">
          <?php else: ?>
            <?php echo strtoupper(substr($currentUser['full_name'] ?? $currentUser['username'], 0, 1)); ?>
          <?php endif; ?>
        </div>
        <span><?php echo htmlspecialchars($currentUser['full_name'] ?? $currentUser['username']); ?></span>
      </div>
      <form method="POST" style="display:inline;">
        <input type="hidden" name="action" value="logout">
        <button type="submit" class="logout-btn">Logout</button>
      </form>
    <?php else: ?>
      <a href="login.php" class="login-btn">Login</a>
      <a href="register.php" class="signup-btn">Sign Up</a>
    <?php endif; ?>
  </nav>
</header>

<div class="main-container">
    <!-- Events Grid -->
    <div class="events-grid">
        <?php if ($result && $result->num_rows > 0): ?>
            <?php while($row = $result->fetch_assoc()): ?>
                <div class="event-card">
                    <?php if (!empty($row['image'])): ?>
                        <img src="images/<?php echo htmlspecialchars($row['image']); ?>" alt="Event Image" style="width:100%; height:auto; border-radius:6px;">
                    <?php endif; ?>
                    <h3><?php echo htmlspecialchars($row['title']); ?></h3>
                    <p><?php echo htmlspecialchars($row['description']); ?></p>
                    <p><strong>Date & Time:</strong> <?php echo date("F j, Y g:i A", strtotime($row['date_time'])); ?></p>
                    <p><strong>Location:</strong> <?php echo htmlspecialchars($row['location']); ?></p>
                  <form method="POST" action="calender.php" style="display:inline;">
    <input type="hidden" name="action" value="add_to_calendar">
    <input type="hidden" name="event_id" value="<?php echo $row['event_id']; ?>">
    <button type="submit" class="calender-btn" title="Add to Calendar">
        📅 Add to Calendar
    </button>
</form>



                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <p>No events available.</p>
        <?php endif; ?>
    </div>

    <!-- Sidebar (Add Event + Manage My Events) -->
    <?php if ($currentUser): ?>
        <div class="sidebar">
            <h2>Add Event</h2>
            <form action="" method="POST" enctype="multipart/form-data">
                <input type="text" name="title" placeholder="Event Title" required>
                <textarea name="description" placeholder="Event Description" required></textarea>
                <input type="datetime-local" name="date_time" required>
                <input type="text" name="location" placeholder="Event Location" required>
                <input type="file" name="image" accept="image/*">
                <button type="submit">Add Event</button>
            </form>

            <h2 style="margin-top:30px;">Manage My Events</h2>
            <?php
            $userEventsResult = $conn->query("SELECT * FROM events WHERE created_by = $currentUserId ORDER BY date_time ASC");
            if ($userEventsResult && $userEventsResult->num_rows > 0): ?>
                <ul>
                    <?php while ($event = $userEventsResult->fetch_assoc()): ?>
                        <li>
                            <span><?php echo htmlspecialchars($event['title']); ?></span>
                            <div style="display:flex; gap:5px;">
                                <a href="edit_event.php?id=<?php echo $event['event_id']; ?>">
                                    <button class="edit-btn" title="Edit">✏️</button>
                                </a>
                                <form action="delete_event.php" method="POST" onsubmit="return confirm('Are you sure you want to delete this event?');">
                                    <input type="hidden" name="id" value="<?php echo $event['event_id']; ?>">
                                    <button type="submit" class="delete-btn" title="Delete">🗑️</button>
                                </form>
                            </div>
                        </li>
                    <?php endwhile; ?>
                </ul>
            <?php else: ?>
                <p>You have not added any events yet.</p>
            <?php endif; ?>
        </div>
    <?php endif; ?>
</div>

</body>
</html>