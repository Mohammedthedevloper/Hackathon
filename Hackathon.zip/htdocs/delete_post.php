<?php
header('Content-Type: application/json');
include 'db_connection.php';

$post_id = isset($_POST['post_id']) ? (int)$_POST['post_id'] : 0;

if ($post_id <= 0) {
  echo json_encode(['success' => false, 'error' => 'Invalid ID']);
  exit;
}

$stmt = $conn->prepare("DELETE FROM posts WHERE post_id = ?");
$stmt->bind_param("i", $post_id);
$ok = $stmt->execute();
$stmt->close();
$conn->close();

echo json_encode(['success' => (bool)$ok]);