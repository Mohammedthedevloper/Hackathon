<?php
header('Content-Type: application/json');
include 'db_connection.php';

$id         = (int)($_POST['id'] ?? 0);
$tutor_name = trim($_POST['tutor_name'] ?? '');
$email      = trim($_POST['email'] ?? '');
$year_level = trim($_POST['year_level'] ?? '');
$faculty    = trim($_POST['faculty'] ?? '');
$module     = trim($_POST['module'] ?? '');
$bio        = trim($_POST['bio'] ?? '');

if ($id<=0 || $tutor_name==='' || $email==='' || $year_level==='' || $faculty==='' || $module==='') {
  echo json_encode(['success'=>false,'error'=>'Invalid payload']); exit;
}
$allowed = ['Year 2','Year 3','Year 4','Postgraduate'];
if (!in_array($year_level, $allowed, true)) {
  echo json_encode(['success'=>false,'error'=>'Invalid year level']); exit;
}
if (strlen($email) > 160) $email = substr($email, 0, 160);

$stmt = $conn->prepare("
  UPDATE tutors
     SET tutor_name=?, email=?, year_level=?, faculty=?, module=?, bio=?
   WHERE id=?");
$stmt->bind_param("ssssssi", $tutor_name, $email, $year_level, $faculty, $module, $bio, $id);

$ok = false;
try {
  $ok = $stmt->execute();
  echo json_encode(['success'=>$ok]);
} catch (mysqli_sql_exception $e) {
  echo json_encode(['success'=>false,'error'=>'Email already exists or invalid data']);
}
$stmt->close(); $conn->close();