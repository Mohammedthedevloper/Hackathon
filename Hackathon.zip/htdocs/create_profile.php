<?php
session_start();
include 'db_connection.php';

// --- Ensure user is logged in ---
if (!isset($_SESSION['user_id'])) {
  header("Location: login.php");
  exit;
}

$currentUserId = $_SESSION['user_id'];

// --- Fetch current user data ---
$stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
$stmt->bind_param("i", $currentUserId);
$stmt->execute();
$currentUser = $stmt->get_result()->fetch_assoc();
$stmt->close();

// --- Handle form submission ---
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  $name = $_POST['name'] ?? '';
  $email = $_POST['email'] ?? '';
  $bio = $_POST['bio'] ?? '';
  $faculty = $_POST['faculty'] ?? '';
  $profileImagePath = $currentUser['profile_image'] ?? null;

  // --- Handle image upload ---
  if (isset($_FILES['profile_image']) && $_FILES['profile_image']['error'] == 0) {
    $allowedExtensions = ['jpg', 'jpeg', 'png', 'gif'];
    $fileName = $_FILES['profile_image']['name'];
    $fileTmp = $_FILES['profile_image']['tmp_name'];
    $fileSize = $_FILES['profile_image']['size'];
    $fileExt = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));

    if (in_array($fileExt, $allowedExtensions)) {
      if ($fileSize < 5 * 1024 * 1024) { // 5MB limit
        $newFileName = 'uploads/profile_' . $currentUserId . '_' . time() . '.' . $fileExt;
        if (!is_dir('uploads')) {
          mkdir('uploads', 0777, true);
        }
        move_uploaded_file($fileTmp, $newFileName);
        $profileImagePath = $newFileName;
      } else {
        echo "<p style='color:red;'>Image too large! Must be under 5MB.</p>";
      }
    } else {
      echo "<p style='color:red;'>Invalid file type! Only JPG, PNG, GIF allowed.</p>";
    }
  }

  // --- Insert or update user data ---
  if ($currentUser) {
    $stmt = $conn->prepare("UPDATE users SET name=?, email=?, bio=?, faculty=?, profile_image=? WHERE id=?");
    $stmt->bind_param("sssssi", $name, $email, $bio, $faculty, $profileImagePath, $currentUserId);
  } else {
    $stmt = $conn->prepare("INSERT INTO users (name, email, bio, faculty, profile_image, id) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssssi", $name, $email, $bio, $faculty, $profileImagePath, $currentUserId);
  }

  if ($stmt->execute()) {
    echo "<p style='color:green;'>Profile saved successfully!</p>";
    header("Refresh:1");
  } else {
    echo "<p style='color:red;'>Error saving profile: " . $stmt->error . "</p>";
  }

  $stmt->close();
  $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Edit Profile</title>
  <style>
    body {
      font-family: 'Poppins', sans-serif;
      background: #f5f7fa;
      color: #333;
      margin: 0;
      padding: 0;
    }
    .container {
      width: 420px;
      background: #fff;
      margin: 60px auto;
      padding: 30px;
      border-radius: 12px;
      box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
    }
    h1 {
      text-align: center;
      color: #1e3a8a;
    }
    label {
      display: block;
      margin-top: 10px;
      font-weight: bold;
    }
    input, textarea, select {
      width: 100%;
      padding: 10px;
      margin-top: 5px;
      border: 1px solid #ccc;
      border-radius: 6px;
      box-sizing: border-box;
      font-size: 15px;
    }
    button {
      background-color: #1e3a8a;
      color: white;
      padding: 10px;
      margin-top: 15px;
      border: none;
      border-radius: 6px;
      cursor: pointer;
      font-size: 16px;
      width: 100%;
    }
    button:hover {
      background-color: #3749c1;
    }
    img {
      display: block;
      margin: 15px auto;
      border-radius: 50%;
      border: 4px solid #1e3a8a;
      width: 120px;
      height: 120px;
      object-fit: cover;
    }
    .back-link {
      text-align: center;
      margin-top: 15px;
    }
    .back-link a {
      color: #1e3a8a;
      font-weight: bold;
      text-decoration: none;
    }
  </style>
</head>
<body>
  <div class="container">
    <h1>Edit Profile</h1>

    <?php if (!empty($currentUser['profile_image'])): ?>
      <img src="<?= htmlspecialchars($currentUser['profile_image']); ?>" alt="Profile Picture">
    <?php endif; ?>

    <form method="POST" enctype="multipart/form-data">
      <label>Name</label>
      <input type="text" name="name" value="<?= htmlspecialchars($currentUser['name'] ?? ''); ?>" required>

      <label>Email</label>
      <input type="email" name="email" value="<?= htmlspecialchars($currentUser['email'] ?? ''); ?>" required>

      <label>Faculty</label>
      <select name="faculty" required>
        <option value="">Select Faculty</option>
        <option value="Engineering" <?= (isset($currentUser['faculty']) && $currentUser['faculty'] == 'Engineering') ? 'selected' : ''; ?>>Engineering</option>
        <option value="Science" <?= (isset($currentUser['faculty']) && $currentUser['faculty'] == 'Science') ? 'selected' : ''; ?>>Science</option>
        <option value="Business" <?= (isset($currentUser['faculty']) && $currentUser['faculty'] == 'Business') ? 'selected' : ''; ?>>Business</option>
        <option value="Arts" <?= (isset($currentUser['faculty']) && $currentUser['faculty'] == 'Arts') ? 'selected' : ''; ?>>Arts</option>
      </select>

      <label>Bio</label>
      <textarea name="bio" rows="4"><?= htmlspecialchars($currentUser['bio'] ?? ''); ?></textarea>

      <label>Profile Picture</label>
      <input type="file" name="profile_image" accept="image/*">

      <button type="submit">Save Profile</button>
    </form>

    <div class="back-link">
      <a href="profile.php">← Back to Profile</a>
    </div>
  </div>
</body>
</html>

