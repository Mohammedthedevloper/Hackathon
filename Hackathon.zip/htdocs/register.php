<?php
include 'db_connection.php';

$success = "";
$error = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $full_name = trim($_POST["full_name"]);
    $username = trim($_POST["username"]);
    $email = trim($_POST["email"]);
    $password = password_hash($_POST["password"], PASSWORD_BCRYPT);
    $role = $_POST["role"];

    $valid_roles = ['student', 'lecturer'];
    if (!in_array($role, $valid_roles)) {
        $role = 'student';
    }

    $sql = "INSERT INTO users (username, email, password_hash, full_name, role) VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssss", $username, $email, $password, $full_name, $role);

    if ($stmt->execute()) {
        $success = "Registration successful! You can now log in.";
    } else {
        $error = "Error: " . $stmt->error;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Register - University Hub</title>
</head>
<body style="
  margin: 0;
  padding: 0;
  font-family: 'Poppins', sans-serif;
  background: url('images/durban_eduvos.jpg') no-repeat center center fixed;
  background-size: cover;
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
">

  <div style="
    background: rgba(255, 255, 255, 0.92);
    padding: 40px;
    border-radius: 15px;
    box-shadow: 0 8px 20px rgba(0,0,0,0.2);
    width: 380px;
    text-align: center;
  ">
    <div style="margin-bottom: 20px;">
      <img src='images/logo.jpg' alt='School Logo' style="width: 80px; height: auto;">
    </div>
    <h2 style="margin-bottom: 10px; color: #333;">Create Account</h2>
    <p style="margin-bottom: 20px; color: #555;">Join the University Hub today</p>

    <form method="POST" action="">
      <input type="text" name="full_name" placeholder="Full Name" style="
        width: 100%;
        padding: 12px;
        margin-bottom: 15px;
        border: 1px solid #ccc;
        border-radius: 8px;
        font-size: 14px;
        box-sizing: border-box;
      ">

      <input type="text" name="username" placeholder="Username" required style="
        width: 100%;
        padding: 12px;
        margin-bottom: 15px;
        border: 1px solid #ccc;
        border-radius: 8px;
        font-size: 14px;
        box-sizing: border-box;
      ">

      <input type="email" name="email" placeholder="Email" required style="
        width: 100%;
        padding: 12px;
        margin-bottom: 15px;
        border: 1px solid #ccc;
        border-radius: 8px;
        font-size: 14px;
        box-sizing: border-box;
      ">

      <input type="password" name="password" placeholder="Password" required style="
        width: 100%;
        padding: 12px;
        margin-bottom: 15px;
        border: 1px solid #ccc;
        border-radius: 8px;
        font-size: 14px;
        box-sizing: border-box;
      ">

      <label for="role" style="
        display: block;
        text-align: left;
        margin-bottom: 8px;
        color: #333;
        font-size: 14px;
      ">Register as:</label>

      <select name="role" id="role" style="
        width: 100%;
        padding: 12px;
        margin-bottom: 20px;
        border: 1px solid #ccc;
        border-radius: 8px;
        font-size: 14px;
        background: #fff;
        box-sizing: border-box;
      ">
        <option value="student">Student</option>
        <option value="lecturer">Lecturer</option>
      </select>

      <button type="submit" style="
        width: 100%;
        background: #007BFF;
        color: white;
        padding: 12px;
        border: none;
        border-radius: 8px;
        cursor: pointer;
        font-size: 15px;
        transition: background 0.3s;
      " onmouseover="this.style.background='#0056b3'" onmouseout="this.style.background='#007BFF'">
        Register
      </button>
    </form>

    <?php if ($success): ?>
      <p style="color: green; margin-top: 15px;"><?= $success ?></p>
    <?php elseif ($error): ?>
      <p style="color: red; margin-top: 15px;"><?= $error ?></p>
    <?php endif; ?>

    <p style="margin-top: 20px; color: #333; font-size: 14px;">
      Already have an account? 
      <a href="login.php" style="color: #007BFF; text-decoration: none; font-weight: 500;">Login here</a>
    </p>
  </div>
</body>
</html>
