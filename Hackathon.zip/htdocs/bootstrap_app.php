<?php
// bootstrap_app.php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_set_cookie_params(['httponly'=>true,'samesite'=>'Lax']);
if (session_status() !== PHP_SESSION_ACTIVE) session_start();

include_once __DIR__.'/db_connection.php';

function e($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }

// Current user (if logged in)
$currentUser = null;
$currentUserId = $_SESSION['user_id'] ?? null;

if ($currentUserId) {
  $stmt = $conn->prepare("SELECT user_id, username, full_name, profile_image, role FROM users WHERE user_id = ?");
  $stmt->bind_param("i", $currentUserId);
  $stmt->execute();
  $currentUser = $stmt->get_result()->fetch_assoc();
  $stmt->close();
}