<?php
session_set_cookie_params(['httponly'=>true,'samesite'=>'Lax']);
session_start();
header('Content-Type: application/json');
require 'db_connection.php';

$userId = $_SESSION['user_id'] ?? null;
$id = (int)($_POST['id'] ?? 0);

if (!$userId) { echo json_encode(['success'=>false,'error'=>'Not logged in']); exit; }
if ($id <= 0) { echo json_encode(['success'=>false,'error'=>'Invalid event id']); exit; }

$sql = "DELETE FROM events WHERE event_id=? AND created_by=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ii", $id, $userId);
$ok = $stmt->execute();

echo json_encode(['success'=>$ok, 'error'=>$ok?null:$stmt->error]);