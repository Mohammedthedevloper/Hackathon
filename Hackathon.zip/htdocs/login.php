<?php
include 'db_connection.php';

$error = "";
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $username = $_POST["username"];
    $password = $_POST["password"];

    $sql = "SELECT * FROM users WHERE username = ? OR email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $username, $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($row = $result->fetch_assoc()) {
        if (password_verify($password, $row["password_hash"])) {
            session_start();
            $_SESSION["user_id"] = $row["user_id"];
            $_SESSION["username"] = $row["username"];
            $_SESSION["role"] = $row["role"];

            if ($row["role"] === "admin") {
                header("Location: admin_dashboard.php");
            } else {
                header("Location: index.php");
            }
            exit();
        } else {
            $error = "Invalid password.";
        }
    } else {
        $error = "User not found.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Login - University Hub</title>
</head>
<body style="
  margin: 0;
  padding: 0;
  font-family: 'Poppins', sans-serif;
  background: url('images/durban_eduvos.jpg') no-repeat center center fixed;
  background-size: cover;
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
">

  <div style="
    background: rgba(255, 255, 255, 0.9);
    padding: 40px;
    border-radius: 15px;
    box-shadow: 0 8px 20px rgba(0,0,0,0.2);
    width: 350px;
    text-align: center;
  ">
    <div style="margin-bottom: 20px;">
      <img src='images/logo.jpg' alt='School Logo' style="width: 80px; height: auto;">
    </div>
    <h2 style="margin-bottom: 10px; color: #333;">Welcome Back</h2>
    <p style="margin-bottom: 20px; color: #555;">Please log in to your account</p>

    <form method="POST" action="">
      <input type="text" name="username" placeholder="Username or Email" required style="
        width: 100%;
        padding: 12px;
        margin-bottom: 15px;
        border: 1px solid #ccc;
        border-radius: 8px;
        font-size: 14px;
        box-sizing: border-box;
      ">
      <input type="password" name="password" placeholder="Password" required style="
        width: 100%;
        padding: 12px;
        margin-bottom: 20px;
        border: 1px solid #ccc;
        border-radius: 8px;
        font-size: 14px;
        box-sizing: border-box;
      ">
      <button type="submit" style="
        width: 100%;
        background: #007BFF;
        color: white;
        padding: 12px;
        border: none;
        border-radius: 8px;
        cursor: pointer;
        font-size: 15px;
        transition: background 0.3s;
      " onmouseover="this.style.background='#0056b3'" onmouseout="this.style.background='#007BFF'">
        Login
      </button>
    </form>

    <?php if ($error): ?>
      <p style="color: red; margin-top: 15px;"><?= $error ?></p>
    <?php endif; ?>

    <p style="margin-top: 20px; color: #333; font-size: 14px;">
      Don't have an account? 
      <a href="register.php" style="color: #007BFF; text-decoration: none; font-weight: 500;">Register here</a>
    </p>
  </div>
</body>
</html>
