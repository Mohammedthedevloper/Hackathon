<?php
session_start();
require_once 'db_connection.php';

// Check login
if (!isset($_SESSION['user_id'])) {
  header('Location: login.php');
  exit;
}

$currentUserId = $_SESSION['user_id'];

// Fetch logged-in user
$stmt = $conn->prepare("SELECT full_name, username, profile_image FROM users WHERE user_id = ?");
$stmt->bind_param("i", $currentUserId);
$stmt->execute();
$currentUser = $stmt->get_result()->fetch_assoc();
$stmt->close();

// Fetch tutors joined with users
$sql = "
  SELECT 
    t.id, t.tutor_name, t.email, t.year_level, t.faculty, t.module, t.bio,
    u.user_id AS tutor_user_id, u.full_name, u.username, u.profile_image
  FROM tutors t
  LEFT JOIN users u ON u.email = t.email
  WHERE (u.role IS NULL OR u.role != 'admin')
  ORDER BY t.updated_at DESC
";
$tutors = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Tutor Chat Board | Campus Connect</title>
<style>
body { margin:0; padding:0; font-family:sans-serif; background:#f3f4f6; color:#111827; }
header { background:#fff; padding:10px 20px; display:flex; align-items:center; justify-content:space-between;
         box-shadow:0 4px 10px rgba(0,0,0,0.05); position:fixed; top:0; left:0; right:0; height:60px; z-index:10; }
.brand { display:flex; align-items:center; gap:10px; }
.brand img { width:40px; border-radius:8px; }
nav a { margin:0 8px; text-decoration:none; color:#374151; font-weight:600; }
nav a.active, nav a:hover { color:#1e3a8a; }

.container { max-width:1100px; margin:80px auto; display:flex; gap:20px; padding:0 16px; }
.list, .chat { background:#fff; border-radius:12px; box-shadow:0 4px 12px rgba(0,0,0,0.08); padding:20px; }
.list { flex:1; max-height:600px; overflow:auto; }
.chat { flex:2; display:flex; flex-direction:column; }

.tutor { display:flex; gap:12px; align-items:center; border-bottom:1px solid #eee; padding:8px 0; cursor:pointer; }
.tutor img { width:50px; height:50px; border-radius:50%; object-fit:cover; border:2px solid #1e3a8a; }
.tutor .info { flex:1; }
.tutor .info h3 { margin:0; font-size:16px; color:#1e3a8a; }
.tutor .info small { color:#6b7280; }

.message { padding:10px; border-radius:10px; margin:6px 0; max-width:70%; }
.message.sent { background:#1e3a8a; color:#fff; align-self:flex-end; }
.message.received { background:#e5e7eb; color:#111; align-self:flex-start; }
.messages { flex:1; overflow:auto; display:flex; flex-direction:column; }
form { display:flex; gap:10px; margin-top:10px; }
form input { flex:1; padding:10px; border-radius:8px; border:1px solid #ccc; }
form button { padding:10px 16px; border:none; border-radius:8px; background:#1e3a8a; color:#fff; cursor:pointer; font-weight:700; }

.dim { color:#6b7280; text-align:center; padding:20px; }
</style>
</head>
<body>

<header>
  <div class="brand">
    <img src="images/logo.jpg" alt="Logo">
    <strong>Campus Connect</strong>
  </div>
  <nav>
    <a href="index.php">Home</a>
    <a href="tutor_chat_board.php" class="active">Tutors</a>
    <a href="messaging.php">Chats</a>
    <a href="profile.php">Profile</a>
  </nav>
</header>

<div class="container">
  <div class="list">
    <h2>Tutors</h2>
    <?php if ($tutors->num_rows > 0): ?>
      <?php while ($t = $tutors->fetch_assoc()): 
        $name = $t['full_name'] ?: $t['tutor_name'];
        $pid = $t['profile_image'] ? "images/{$t['profile_image']}" : "images/default.png";
      ?>
      <div class="tutor" onclick="openChat(<?= (int)$t['tutor_user_id'] ?>, '<?= htmlspecialchars($name) ?>')">
        <img src="<?= htmlspecialchars($pid) ?>" alt="">
        <div class="info">
          <h3><?= htmlspecialchars($name) ?></h3>
          <small><?= htmlspecialchars($t['module']) ?> • <?= htmlspecialchars($t['year_level']) ?></small><br>
          <small><?= htmlspecialchars($t['faculty']) ?></small>
        </div>
      </div>
      <?php endwhile; ?>
    <?php else: ?>
      <p class="dim">No tutors available.</p>
    <?php endif; ?>
  </div>

  <div class="chat">
    <h2 id="chatTitle">Chat</h2>
    <div id="messages" class="messages"><p class="dim">Select a tutor to start chatting.</p></div>
    <form id="chatForm" onsubmit="return false;" style="display:none;">
      <input type="text" name="message" placeholder="Type a message..." required>
      <button type="submit">Send</button>
    </form>
  </div>
</div>

<script>
let peerId = 0;

function openChat(id, name){
  peerId = id;
  document.getElementById('chatTitle').textContent = 'Chat with ' + name;
  document.getElementById('messages').innerHTML = '';
  document.getElementById('chatForm').style.display = 'flex';
  loadMessages();
}

async function loadMessages(){
  if(!peerId) return;
  const res = await fetch(`messages.php?peer_id=${peerId}`);
  const data = await res.json();
  const box = document.getElementById('messages');
  box.innerHTML = '';
  data.messages.forEach(m=>{
    const div=document.createElement('div');
    div.className='message '+(m.is_me?'sent':'received');
    div.textContent=m.html.replace(/<[^>]+>/g,'');
    box.appendChild(div);
  });
  box.scrollTop = box.scrollHeight;
}

document.getElementById('chatForm').addEventListener('submit',async e=>{
  e.preventDefault();
  const msg = e.target.message.value.trim();
  if(!msg) return;
  await fetch('send_message.php',{
    method:'POST',
    headers:{'Content-Type':'application/x-www-form-urlencoded'},
    body:`receiver_id=${peerId}&message=${encodeURIComponent(msg)}`
  });
  e.target.message.value='';
  loadMessages();
});
</script>
</body>
</html>
