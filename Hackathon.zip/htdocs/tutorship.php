<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include 'db_connection.php';

// --- Set current user ---
$currentUserId = 1; 
$currentUserQuery = $conn->query("SELECT username, full_name, profile_image FROM users WHERE user_id = $currentUserId");
$currentUser = $currentUserQuery->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Campus Connect — Tutorship</title>
  <style>
    /* === BASE === */
    :root {
      --accent: #1e3a8a;
      --muted: #6b7280;
      --card-bg: #ffffff;
      --page-bg: #f3f4f6;
      --radius: 12px;
      --shadow: 0 6px 18px rgba(0,0,0,0.08);
      font-family: Inter, system-ui, -apple-system, "Segoe UI", Roboto, Arial;
    }
    * { margin: 0; padding: 0; box-sizing: border-box; }

    body {
      background: url('https://images.unsplash.com/photo-1523580846011-d3a5bc25702b') no-repeat center center fixed;
      background-size: cover;
      color: #333;
      font-family: Arial, sans-serif;
      padding-top: 80px;
    }

    /* === HEADER (from index.php) === */
    header {
      position: fixed; top: 0; left: 0; right: 0; height: 60px;
      background: #fff; display: flex; align-items: center; justify-content: space-between;
      padding: 0 20px; box-shadow: 0 6px 18px rgba(0,0,0,0.08); z-index: 1000;
    }
    .brand { display: flex; align-items: center; gap: 12px; }
    .logo { width: 48px; height: 48px; border-radius: 8px; overflow: hidden; background: #1e3a8a; display: flex; align-items: center; justify-content: center; }
    .logo img { width: 100%; height: 100%; object-fit: cover; }
    .site-title { font-weight: 700; font-size: 20px; color: #1e3a8a; }
    nav { display: flex; gap: 12px; align-items: center; }
    nav a { padding: 8px 14px; border-radius: 8px; font-weight: 600; color: #6b7280; transition: 0.2s; }
    nav a.active, nav a:hover { background: rgba(30,58,138,0.1); color: #1e3a8a; }
    .login-btn, .signup-btn { padding: 8px 16px; border-radius: 8px; border: none; font-weight: 600; cursor: pointer; transition: 0.2s; }
    .login-btn { background: white; color: #1e3a8a; border: 1px solid #1e3a8a; }
    .login-btn:hover { background: #1e3a8a; color: white; }
    .signup-btn { background: #1e3a8a; color: white; }
    .signup-btn:hover { background: #153e75; }

    /* === CONTENT === */
    .overlay {
      background: rgba(255, 255, 255, 0.95);
      padding: 40px;
      border-radius: var(--radius);
      max-width: 1100px;
      margin: 40px auto;
      box-shadow: var(--shadow);
      text-align: center;
    }

    h1 { font-size: 2.5em; color: var(--accent); margin-bottom: 20px; }
    h2 { font-size: 2em; color: var(--accent); margin-top: 50px; margin-bottom: 20px; }
    p { font-size: 1.1em; line-height: 1.6; margin-bottom: 30px; }

    /* === TUTOR CARDS === */
    .tutor-container {
      display: flex; flex-wrap: wrap; justify-content: center; gap: 20px;
    }
    .tutor-card {
      background: #f9f9f9;
      border-radius: var(--radius);
      padding: 20px;
      width: 250px;
      text-align: center;
      box-shadow: var(--shadow);
      transition: transform 0.3s ease, box-shadow 0.3s ease;
    }
    .tutor-card:hover { transform: translateY(-6px); box-shadow: 0px 6px 18px rgba(0,0,0,0.2); }
    .tutor-card img { width: 100px; height: 100px; border-radius: 50%; border: 3px solid var(--accent); margin-bottom: 15px; }
    .tutor-card h3 { margin: 10px 0 5px; color: var(--accent); }
    .tutor-card p { font-size: 0.95em; margin: 5px 0; }
    .contact-btn {
      display: inline-block; margin-top: 10px; padding: 8px 14px;
      background: var(--accent); color: white; border-radius: 8px;
      text-decoration: none; font-weight: bold; transition: background 0.3s ease;
    }
    .contact-btn:hover { background: #153e75; }

    .signup-section {
      margin-top: 50px;
      padding: 30px;
      background: #f9f9f9;
      border-radius: var(--radius);
      box-shadow: var(--shadow);
      text-align: center;
    }
    .signup-btn {
      display: inline-block; margin-top: 15px; padding: 12px 20px;
      background: var(--accent); color: white; border-radius: 8px;
      text-decoration: none; font-weight: bold; font-size: 1.1em;
      transition: background 0.3s ease;
    }
    .signup-btn:hover { background: #153e75; }
  </style>
</head>
<body>

<header>
  <div class="brand">
    <div class="logo"><img src="images/logo.jpg" alt="Logo"></div>
    <span class="site-title">Campus Connect</span>
  </div>
  <nav>
    <a href="index.php">Home</a>
    <a href="about.html">About</a>
    <a href="profile.html">Profile</a>
    <a href="events.php">Events</a>
    <a href="chat.php">Chats</a>
    <button class="login-btn">Login</button>
    <button class="signup-btn">Sign Up</button>
  </nav>
</header>

<div class="overlay">
  <h1>Peer Tutorship</h1>
  <p>
    At CampusConnect, we believe students succeed best when they support each other.  
    Our Tutorship Program connects peers who need help with subjects to those who are skilled in them.  
    Whether it’s exam prep, coding assignments, or project guidance, our community has your back.
  </p>

  <h2>IT & Science Tutors</h2>
  <div class="tutor-container">
    <div class="tutor-card">
      <img src="https://via.placeholder.com/100" alt="Tutor 1">
      <h3>Thabo M.</h3>
      <p><strong>Subject:</strong> Data Structures</p>
      <p><strong>Year:</strong> 3rd Year</p>
      <a href="mailto:thabo@vossie.net" class="contact-btn">Contact</a>
    </div>
    <div class="tutor-card">
      <img src="https://via.placeholder.com/100" alt="Tutor 2">
      <h3>Amara K.</h3>
      <p><strong>Subject:</strong> Web Development</p>
      <p><strong>Year:</strong> 2nd Year</p>
      <a href="mailto:amara@vossie.net" class="contact-btn">Contact</a>
    </div>
    <div class="tutor-card">
      <img src="https://via.placeholder.com/100" alt="Tutor 3">
      <h3>Daniel S.</h3>
      <p><strong>Subject:</strong> Database Systems</p>
      <p><strong>Year:</strong> 3rd Year</p>
      <a href="mailto:daniel@vossie.net" class="contact-btn">Contact</a>
    </div>
  </div>

  <h2>Commerce Tutors</h2>
  <div class="tutor-container">
    <div class="tutor-card">
      <img src="https://via.placeholder.com/100" alt="Tutor 4">
      <h3>Lerato D.</h3>
      <p><strong>Subject:</strong> Financial Accounting</p>
      <p><strong>Year:</strong> 3rd Year</p>
      <a href="mailto:lerato@vossie.net" class="contact-btn">Contact</a>
    </div>
    <div class="tutor-card">
      <img src="https://via.placeholder.com/100" alt="Tutor 5">
      <h3>Sipho N.</h3>
      <p><strong>Subject:</strong> Business Management</p>
      <p><strong>Year:</strong> 2nd Year</p>
      <a href="mailto:sipho@vossie.net" class="contact-btn">Contact</a>
    </div>
  </div>

  <h2>Humanities Tutors</h2>
  <div class="tutor-container">
    <div class="tutor-card">
      <img src="https://via.placeholder.com/100" alt="Tutor 6">
      <h3>Nomvula R.</h3>
      <p><strong>Subject:</strong> Psychology</p>
      <p><strong>Year:</strong> 3rd Year</p>
      <a href="mailto:nomvula@vossie.net" class="contact-btn">Contact</a>
    </div>
    <div class="tutor-card">
      <img src="https://via.placeholder.com/100" alt="Tutor 7">
      <h3>Emmanuel T.</h3>
      <p><strong>Subject:</strong> Sociology</p>
      <p><strong>Year:</strong> 2nd Year</p>
      <a href="mailto:emmanuel@vossie.net" class="contact-btn">Contact</a>
    </div>
  </div>

  <h2>Become a Tutor</h2>
  <div class="signup-section">
    <p>
      Share your skills, build your CV, and make a difference in your fellow students’ lives.  
      Sign up to join our network of tutors today!
    </p>
    <a href="Tutorship sign up.html" class="signup-btn">Sign Up to be a Tutor</a>
  </div>
</div>

<?php $conn->close(); ?>
</body>
</html>