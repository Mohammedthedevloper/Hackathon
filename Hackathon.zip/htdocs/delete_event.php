<?php
// Show errors for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Include your database connection
include 'db_connection.php';

// Check if ID is provided
if (!isset($_POST['id'])) {
    die("No event ID provided.");
}

$event_id = intval($_POST['id']);

// Optional: Fetch event to delete its image
$result = $conn->query("SELECT image FROM events WHERE event_id = $event_id");
if ($result && $result->num_rows > 0) {
    $event = $result->fetch_assoc();

    // Delete the image file if it exists
    if (!empty($event['image']) && file_exists("images/" . $event['image'])) {
        unlink("images/" . $event['image']);
    }
}

// Delete event from database
$sql = "DELETE FROM events WHERE event_id = $event_id";
if ($conn->query($sql)) {
    // Redirect back to events page
    header("Location: events.php");
    exit;
} else {
    echo "Error deleting event: " . $conn->error;
}
?>
