<?php
session_set_cookie_params(['httponly'=>true,'samesite'=>'Lax']);
session_start();
require 'db_connection.php';

// ========== 1️⃣ Add event to user calendar ==========
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add_to_calendar') {
    if (!isset($_SESSION['user_id'])) {
        header("Location: login.php");
        exit;
    }

    $userId = $_SESSION['user_id'];
    $eventId = $_POST['event_id'] ?? null;

    if ($eventId) {
        // Check if already exists
        $check = $conn->prepare("SELECT 1 FROM user_events WHERE user_id = ? AND event_id = ?");
        $check->bind_param("ii", $userId, $eventId);
        $check->execute();
        $exists = $check->get_result()->num_rows > 0;
        $check->close();

        if (!$exists) {
            $stmt = $conn->prepare("INSERT INTO user_events (user_id, event_id, added_at) VALUES (?, ?, NOW())");
            $stmt->bind_param("ii", $userId, $eventId);
            $stmt->execute();
            $stmt->close();
        }
    }

    header("Location: calender.php");
    exit;
}

// ========== 2️⃣ Load user’s personalized events (AJAX request) ==========
if (isset($_GET['load']) && $_GET['load'] === 'events') {
    header('Content-Type: application/json');

    if (!isset($_SESSION['user_id'])) {
        http_response_code(403);
        echo json_encode(["error" => "User not logged in"]);
        exit;
    }

    $userId = $_SESSION['user_id'];

    $stmt = $conn->prepare("
        SELECT 
            e.event_id AS id,
            e.title,
            e.description,
            e.date_time AS start,
            e.location
        FROM user_events ue
        INNER JOIN events e ON ue.event_id = e.event_id
        WHERE ue.user_id = ?
        ORDER BY e.date_time ASC
    ");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();

    $events = [];
    while ($row = $result->fetch_assoc()) {
        $events[] = [
            'id' => $row['id'],
            'title' => $row['title'],
            'start' => $row['start'],
            'description' => $row['description'],
            'location' => $row['location']
        ];
    }

    echo json_encode($events);
    exit;
}

// ========== 3️⃣ Normal page rendering ==========
$currentUserId = $_SESSION['user_id'] ?? null;
$currentUser = null;
if ($currentUserId) {
  $stmt = $conn->prepare("SELECT user_id, username, full_name, profile_image FROM users WHERE user_id=?");
  $stmt->bind_param("i", $currentUserId);
  $stmt->execute();
  $currentUser = $stmt->get_result()->fetch_assoc();
  $stmt->close();
}

// ---- Logout ----
if ($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['action']??'')==='logout') {
  session_unset(); session_destroy();
  header("Location: calender.php"); exit();
}

// Fetch all events to display buttons
$eventsResult = $conn->query("SELECT * FROM events ORDER BY date_time ASC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Campus Connect - Calendar</title>
<link href="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.8/index.global.min.css" rel="stylesheet">
<style>
body{margin:0;padding:0;font-family:sans-serif;background:#f9fafb;color:#111827}
a{text-decoration:none;color:inherit}
header{position:fixed;top:0;left:0;right:0;height:60px;background:#fff;display:flex;align-items:center;justify-content:space-between;padding:0 20px;box-shadow:0 6px 18px rgba(0,0,0,.08);z-index:1000}
.brand{display:flex;align-items:center;gap:12px}
.logo{width:48px;height:48px;border-radius:8px;overflow:hidden;background:#1e3a8a;display:flex;align-items:center;justify-content:center}
.logo img{width:100%;height:100%;object-fit:cover}
.site-title{font-weight:700;font-size:20px;color:#1e3a8a}
nav{display:flex;gap:12px;align-items:center}
nav a{padding:8px 14px;border-radius:8px;font-weight:600;color:#6b7280;transition:.2s}
nav a.active,nav a:hover{background:rgba(30,58,138,.1);color:#1e3a8a}
.user-info{display:flex;align-items:center;gap:8px;margin-left:8px}
.user-avatar{width:32px;height:32px;border-radius:50%;overflow:hidden;background:#e5e7eb;display:flex;align-items:center;justify-content:center;font-weight:700;color:#374151}
.user-avatar img{width:100%;height:100%;object-fit:cover}
.logout-btn,.login-btn,.add-btn{border:none;border-radius:8px;padding:8px 12px;font-weight:600;cursor:pointer}
.logout-btn{background:#ef4444;color:#fff}
.login-btn{background:#1e3a8a;color:#fff}
.add-btn{background:#10b981;color:#fff;margin:5px 0;}
.container{margin-top:80px;padding:20px}
#calendar{max-width:900px;margin:0 auto;height:700px}
.event-buttons{margin:20px 0;display:flex;flex-wrap:wrap;gap:10px;}
</style>
</head>
<body>

<header>
  <div class="brand">
    <div class="logo"><img src="images/logo.jpg" alt="Logo"></div>
    <span class="site-title">Campus Connect</span>
  </div>

  <nav>
    <a href="index.php">Home</a>
    <a href="about.php">About</a>
    <a href="profile.php">Profile</a>
    <a href="events.php">Events</a>
    <a href="calender.php" class="active">Calendar</a>
    <a href="tutorship.php">Tutorship</a>
    <a href="messaging.php">Chats</a>

    <?php if ($currentUser): ?>
      <div class="user-info">
        <div class="user-avatar">
          <?php if (!empty($currentUser['profile_image'])): ?>
            <img src="images/<?php echo htmlspecialchars($currentUser['profile_image']); ?>" alt="Avatar">
          <?php else: ?>
            <?php echo strtoupper(substr($currentUser['full_name'] ?? $currentUser['username'], 0, 1)); ?>
          <?php endif; ?>
        </div>
        <span><?php echo htmlspecialchars($currentUser['full_name'] ?? $currentUser['username']); ?></span>
      </div>
      <form method="POST" style="display:inline;">
        <input type="hidden" name="action" value="logout">
        <button type="submit" class="logout-btn">Logout</button>
      </form>
    <?php else: ?>
      <a href="login.php" class="login-btn">Login</a>
    <?php endif; ?>
  </nav>
</header>

<div class="container">
  <div id="calendar"></div>



<script src="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.8/index.global.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function () {
  const calendarEl = document.getElementById('calendar');
  const calendar = new FullCalendar.Calendar(calendarEl, {
    initialView: 'dayGridMonth',
    headerToolbar: { left: 'prev,next today', center: 'title', right: 'dayGridMonth,timeGridWeek,timeGridDay,listWeek' },
    events: 'calender.php?load=events', 
    eventClick: function(info){
      const ev = info.event;
      alert(
        "Title: " + ev.title + "\n" +
        "Date & Time: " + (ev.start ? ev.start.toLocaleString() : '') + "\n" +
        "Location: " + (ev.extendedProps.location || '') + "\n" +
        "Description: " + (ev.extendedProps.description || '')
      );
    }
  });
  calendar.render();
});
</script>

</body>
</html>
