<?php
session_start();

// Fixed user for testing
$currentUserId = 1;

// Escape function
function e($text) {
    return htmlspecialchars($text ?? '', ENT_QUOTES, 'UTF-8');
}

// CSRF token helpers
function csrf_token() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function csrf_verify($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

// Rate limiting (optional)
function rate_limit($key, $maxPerMinute = 60) {
    $now = time();
    $_SESSION['rate_limit'][$key] = array_filter($_SESSION['rate_limit'][$key] ?? [], fn($t) => $t > $now - 60);
    if (count($_SESSION['rate_limit'][$key]) >= $maxPerMinute) {
        return false;
    }
    $_SESSION['rate_limit'][$key][] = $now;
    return true;
}
?>
