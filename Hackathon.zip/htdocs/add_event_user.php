<?php
session_set_cookie_params(['httponly'=>true,'samesite'=>'Lax']);
session_start();
header('Content-Type: application/json');
require 'db_connection.php';

$userId = $_SESSION['user_id'] ?? null;
if (!$userId) { echo json_encode(['success'=>false,'error'=>'Not logged in']); exit; }

$title = trim($_POST['title'] ?? '');
$description = trim($_POST['description'] ?? '');
$location = trim($_POST['location'] ?? '');
$dateTime = $_POST['date_time'] ?? '';

if ($title === '' || $dateTime === '') {
  echo json_encode(['success'=>false,'error'=>'Missing title or date/time']); exit;
}

$sql = "INSERT INTO events (title, description, date_time, location, created_by)
        VALUES (?, ?, ?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ssssi", $title, $description, $dateTime, $location, $userId);
$ok = $stmt->execute();

echo json_encode(['success'=>$ok, 'id'=>$ok ? $stmt->insert_id : null, 'error'=>$ok?null:$stmt->error]);