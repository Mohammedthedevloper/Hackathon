<?php
// Include DB connection
include 'db_connection.php';

// Enable error reporting
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Check if event_id is passed
if (!isset($_GET['id'])) {
    die("No event ID provided.");
}

$event_id = intval($_GET['id']);

// Fetch event details
$result = $conn->query("SELECT * FROM events WHERE event_id = $event_id");
if (!$result) {
    die("Error fetching event: " . $conn->error);
}

if ($result->num_rows == 0) {
    die("Event not found.");
}

$event = $result->fetch_assoc();

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = $conn->real_escape_string($_POST['title']);
    $description = $conn->real_escape_string($_POST['description']);
    $date_time = $conn->real_escape_string($_POST['date_time']);
    $location = $conn->real_escape_string($_POST['location']);

    // Handle optional new image upload
    $imagePath = $event['image'];
    if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $targetDir = "images/"; 
        $fileName = time() . "_" . basename($_FILES["image"]["name"]);
        $targetFile = $targetDir . $fileName;
        if (move_uploaded_file($_FILES["image"]["tmp_name"], $targetFile)) {
            $imagePath = $fileName;
        }
    }

    // Update event in DB
    $sql = "UPDATE events 
            SET title='$title', description='$description', date_time='$date_time', location='$location', image='$imagePath' 
            WHERE event_id=$event_id";

    if ($conn->query($sql)) {
        // Redirect back to events page after update
        header("Location: events.php");
        exit;
    } else {
        echo "Error updating event: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Edit Event</title>
<style>
body { font-family: Arial; padding: 20px; background: #f4f6f9; }
form { background: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); max-width: 500px; }
input, textarea, button { display:block; margin-bottom:10px; width:100%; padding:8px; border:1px solid #ccc; border-radius:6px; }
button { background:#0066cc; color:white; border:none; cursor:pointer; }
button:hover { opacity:0.85; }
img { margin-top:10px; border:1px solid #ccc; border-radius:6px; }
h2 { color: #1e3a8a; }
</style>
</head>
<body>

<h2>Edit Event</h2>
<form action="" method="POST" enctype="multipart/form-data">
    <label>Event Title:</label>
    <input type="text" name="title" value="<?php echo htmlspecialchars($event['title']); ?>" required>

    <label>Event Description:</label>
    <textarea name="description" required><?php echo htmlspecialchars($event['description']); ?></textarea>

    <label>Date & Time:</label>
    <input type="datetime-local" name="date_time" value="<?php echo date('Y-m-d\TH:i', strtotime($event['date_time'])); ?>" required>

    <label>Location:</label>
    <input type="text" name="location" value="<?php echo htmlspecialchars($event['location']); ?>" required>

    <label>Event Image (optional):</label>
    <input type="file" name="image" accept="image/*">

    <?php if($event['image']): ?>
        <p>Current Image:</p>
        <img src="images/<?php echo $event['image']; ?>" style="width:150px; height:auto;">
    <?php endif; ?>

    <button type="submit">Update Event</button>
</form>

</body>
</html>
