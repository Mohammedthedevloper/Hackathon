<?php
header('Content-Type: application/json');
include 'db_connection.php';

$sql = "SELECT COUNT(*) AS total_users FROM users";
$result = $conn->query($sql);
$total_users = 0;

if ($result && $row = $result->fetch_assoc()) {
  $total_users = $row['total_users'];
}

echo json_encode(['total_users' => $total_users]);
$conn->close();