<?php
ini_set('display_errors',1);
ini_set('display_startup_errors',1);
error_reporting(E_ALL);

require_once 'bootstrap_app.php'; // gives $conn and $currentUser (user_id, username, full_name, profile_image)
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Campus Connect | About Us</title>
<style>
  body { margin:0; padding:0; font-family:sans-serif; background:#f9fafb; color:#111827; }

  /* ===== Older header style (inline, no include) ===== */
  header{position:fixed;top:0;left:0;right:0;height:60px;background:#fff;display:flex;align-items:center;justify-content:space-between;padding:0 20px;box-shadow:0 6px 18px rgba(0,0,0,0.08);z-index:1000}
  .brand{display:flex;align-items:center;gap:12px}
  .logo{width:48px;height:48px;border-radius:8px;overflow:hidden;background:#1e3a8a;display:flex;align-items:center;justify-content:center}
  .logo img{width:100%;height:100%;object-fit:cover}
  .site-title{font-weight:700;font-size:20px;color:#1e3a8a}
  nav{display:flex;gap:12px;align-items:center;flex-wrap:wrap}
  nav a{padding:8px 14px;border-radius:8px;font-weight:600;color:#6b7280;transition:.2s;text-decoration:none}
  nav a.active,nav a:hover{background:rgba(30,58,138,0.1);color:#1e3a8a}
  .user-info{display:flex;align-items:center;gap:8px;padding:6px 10px;border-radius:8px;background:#f3f4f6}
  .user-avatar{width:28px;height:28px;border-radius:50%;overflow:hidden;display:flex;align-items:center;justify-content:center;background:#e5e7eb;font-weight:700;color:#374151}
  .user-avatar img{width:100%;height:100%;object-fit:cover}
  .logout-btn,.login-btn,.signup-btn{padding:8px 12px;border-radius:8px;border:none;font-weight:600;cursor:pointer}
  .logout-btn{background:#ef4444;color:#fff}
  .login-btn{background:#fff;color:#1e3a8a;border:1px solid #1e3a8a}
  .signup-btn{background:#1e3a8a;color:#fff}

  /* page spacing below fixed header */
  .page {padding-top:80px}

  /* ===== About content ===== */
  .overlay{background:#fff; padding:40px; border-radius:12px; max-width:1000px; margin:40px auto; color:#333; box-shadow:0 6px 18px rgba(0,0,0,0.08)}
  h1,h2{text-align:center;margin-bottom:20px}
  h1{font-size:2.5em;color:#1e3a8a}
  h2{font-size:2em;color:#1e3a8a;margin-top:50px}
  p{font-size:1.1em; line-height:1.6; margin-bottom:15px; text-align:center}
  ul{ text-align:left; margin:20px auto; max-width:600px }
  ul li{ margin-bottom:10px }
  .team-container{display:flex;flex-wrap:wrap;justify-content:center;gap:20px;margin-top:30px}
  .team-member{background:#f9f9f9;border-radius:12px;padding:20px;text-align:center;width:200px;box-shadow:0 6px 18px rgba(0,0,0,0.08)}
  .team-member img{width:100px;height:100px;border-radius:50%;margin-bottom:15px;border:3px solid #1e3a8a;object-fit:cover}
  .contact-container{margin-top:40px;background:#f9f9f9;padding:25px;border-radius:12px;box-shadow:0 6px 18px rgba(0,0,0,0.08);max-width:700px;margin-left:auto;margin-right:auto;text-align:center}
  .contact-container ul{list-style:none;padding:0;margin:0}
  .contact-container a{color:#1e3a8a;font-weight:600;text-decoration:none}
  .contact-container a:hover{text-decoration:underline}
</style>
</head>
<body>
<header>
  <div class="brand">
    <div class="logo"><img src="images/logo.jpg" alt="Logo"></div>
    <span class="site-title">Campus Connect</span>
  </div>

  <nav>
    <a href="index.php">Home</a>
    <a href="about.php" class="active">About</a>
    <a href="profile.php">Profile</a>
    <a href="events.php">Events</a>
    <a href="tutorship.php">Tutorship</a>
    <a href="messaging.php">Chats</a>

    <?php if (!empty($currentUser)): ?>
      <div class="user-info">
        <div class="user-avatar">
          <?php if (!empty($currentUser['profile_image'])): ?>
            <img src="images/<?= htmlspecialchars($currentUser['profile_image'], ENT_QUOTES, 'UTF-8') ?>" alt="Avatar">
          <?php else: ?>
            <?= strtoupper(substr(($currentUser['full_name'] ?? $currentUser['username'] ?? 'U'), 0, 1)) ?>
          <?php endif; ?>
        </div>
        <span><?= htmlspecialchars(($currentUser['full_name'] ?? $currentUser['username'] ?? ''), ENT_QUOTES, 'UTF-8') ?></span>
      </div>
      <form method="POST" action="logout.php" style="display:inline">
        <button type="submit" class="logout-btn">Logout</button>
      </form>
    <?php else: ?>
      <a href="login.php" class="login-btn">Login</a>
      <a href="register.php" class="signup-btn">Sign Up</a>
    <?php endif; ?>
  </nav>
</header>

<div class="page">
  <div class="overlay">
    <h1>About CampusConnect</h1>
    <p>At CampusConnect, we bring students closer to opportunities, people, and skills that prepare them for life after university.</p>
    <ul>
      <li>Central space to connect and collaborate.</li>
      <li>Relevant internships, events, and workshops.</li>
      <li>Safe, student-first environment.</li>
      <li>Tools for teamwork and discussions.</li>
    </ul>

    <h2>Meet the Team</h2>
    <div class="team-container">
      <div class="team-member"><img src="https://via.placeholder.com/100" alt=""><h3>Fanele</h3><p>3rd Year — IT</p></div>
      <div class="team-member"><img src="https://via.placeholder.com/100" alt=""><h3>Ria</h3><p>3rd Year — IT</p></div>
      <div class="team-member"><img src="https://via.placeholder.com/100" alt=""><h3>Ndalo</h3><p>3rd Year — IT</p></div>
      <div class="team-member"><img src="https://via.placeholder.com/100" alt=""><h3>Justine</h3><p>3rd Year — IT</p></div>
      <div class="team-member"><img src="https://via.placeholder.com/100" alt=""><h3>Aria</h3><p>2nd Year — DS</p></div>
      <div class="team-member"><img src="https://via.placeholder.com/100" alt=""><h3>Mohammed</h3><p>3rd Year — IT</p></div>
    </div>

    <h2>Contact Us</h2>
    <div class="contact-container">
      <ul>
        <li><strong>Support:</strong> <a href="mailto:support@vossie.net">support@vossie.net</a></li>
      </ul>
    </div>
  </div>
</div>

<?php $conn && $conn->close(); ?>
</body>
</html>