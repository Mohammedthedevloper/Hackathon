<?php
header('Content-Type: application/json');
include 'db_connection.php';

// Basic rate limit by IP (simple)
session_start();
$now = time();
$_SESSION['add_user_times'] = array_filter($_SESSION['add_user_times'] ?? [], fn($t)=>$t>$now-60);
if (count($_SESSION['add_user_times']) >= 20) { echo json_encode(['success'=>false,'error'=>'Too many requests']); exit; }
$_SESSION['add_user_times'][] = $now;

$username  = trim($_POST['username'] ?? '');
$email     = trim($_POST['email'] ?? '');
$full_name = trim($_POST['full_name'] ?? '');
$password  = $_POST['password'] ?? '';

if ($username === '' || $email === '' || $password === '') {
  echo json_encode(['success'=>false,'error'=>'Username, email and password are required']); exit;
}
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
  echo json_encode(['success'=>false,'error'=>'Invalid email']); exit;
}
if (strlen($username) < 3 || strlen($username) > 50) {
  echo json_encode(['success'=>false,'error'=>'Username length must be 3-50']); exit;
}
if (strlen($password) < 6) {
  echo json_encode(['success'=>false,'error'=>'Password too short']); exit;
}

// Check duplicates
$stmt = $conn->prepare("SELECT 1 FROM users WHERE username=? OR email=? LIMIT 1");
$stmt->bind_param("ss", $username, $email);
$stmt->execute();
$dup = $stmt->get_result()->fetch_row();
$stmt->close();
if ($dup) { echo json_encode(['success'=>false,'error'=>'Username or email already exists']); exit; }

// Hash password
$hash = password_hash($password, PASSWORD_DEFAULT);

// Insert
$stmt = $conn->prepare("INSERT INTO users (username, email, password_hash, full_name) VALUES (?,?,?,?)");
$stmt->bind_param("ssss", $username, $email, $hash, $full_name);
$ok = $stmt->execute();
$uid = $ok ? (int)$stmt->insert_id : 0;
$stmt->close();

echo json_encode(['success'=>$ok, 'user_id'=>$uid]);
$conn->close();


