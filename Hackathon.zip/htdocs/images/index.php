<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);
include 'db_connection.php';


// --- Set current user for welcome banner/demo purposes ---
$currentUserId = 1; // you can later set dynamically from login
$currentUserQuery = $conn->query("SELECT username, full_name, profile_image FROM users WHERE user_id = $currentUserId");
$currentUser = $currentUserQuery->fetch_assoc();

// --- Fetch posts with user info ---
$posts_sql = "
    SELECT p.post_id, p.content, p.image, p.created_at, 
           u.full_name AS author, u.username, u.profile_image
    FROM posts p
    JOIN users u ON p.user_id = u.user_id
    ORDER BY p.created_at DESC
";
$posts_result = $conn->query($posts_sql);

// --- Fetch events ---
$events_sql = "
    SELECT event_id, title, description, date_time, location, profile_image
    FROM events
    ORDER BY date_time ASC
";
$events_result = $conn->query($events_sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Campus Connect | Home</title>
<link rel="stylesheet" href="styles.css">
</head>

<body>
  <!-- Header -->
  <div id="site-header"></div>
  <script src="header.js"></script>

  <!-- Main container -->
  <div class="container">
    
    <!-- Welcome -->
    <div class="welcome card">
      <div class="left">
        <h1 id="welcome-text">Welcome, <?php echo htmlspecialchars($currentUser['full_name']); ?>!</h1>
        <p id="date-text"></p>
      </div>
      <div>
        <button class="action-btn primary" onclick="alert('Create Post modal coming soon!')">Post update</button>
      </div>
    </div>

    <!-- Main content -->
    <div class="main">
      
      <!-- Feed column -->
      <section class="feed">
        <div class="card">
          <h2>Campus Feed</h2>
          <small style="color:var(--muted)">Showing latest updates</small>
        </div>

        <?php if($posts_result && $posts_result->num_rows > 0): ?>
          <?php while($p = $posts_result->fetch_assoc()): ?>
            <div class="card post">
              <div class="avatar">
                <?php if(!empty($p['profile_image'])): ?>
                  <img src="images/<?php echo htmlspecialchars($p['profile_image']); ?>" alt="User" style="width:100%; height:100%; border-radius:50%;">
                <?php else: ?>
                  <?php echo strtoupper(substr($p['author'] ?: $p['username'], 0, 1)); ?>
                <?php endif; ?>
              </div>
              <div style="flex:1">
                <div class="meta"><?php echo htmlspecialchars($p['author'] ?: $p['username']); ?> <small><?php echo date("M j, Y g:i a", strtotime($p['created_at'])); ?></small></div>
                <p><?php echo nl2br(htmlspecialchars($p['content'])); ?></p>
                <?php if(!empty($p['image'])): ?>
                  <img src="images/<?php echo htmlspecialchars($p['image']); ?>" alt="Post Image" class="post-image" style="width:100%;border-radius:8px;margin-top:8px;">
                <?php endif; ?>
                <div class="actions">
                  <button class="action-btn">Like</button>
                  <button class="action-btn">Comment</button>
                  <button class="action-btn">Share</button>
                </div>
              </div>
            </div>
          <?php endwhile; ?>
        <?php else: ?>
          <p class="no-data">No posts found.</p>
        <?php endif; ?>
      </section>

      <!-- Sidebar -->
      <aside>
        <div class="card">
          <h3>Upcoming Events</h3>
          <div class="events">
            <?php if($events_result && $events_result->num_rows > 0): ?>
              <?php while($e = $events_result->fetch_assoc()): ?>
                <div class="event-item card">
                  <?php if(!empty($e['image'])): ?>
                    <img src="images/<?php echo htmlspecialchars($e['image']); ?>" alt="Event" class="event-thumb">
                  <?php endif; ?>
                  <div>
                    <strong><?php echo htmlspecialchars($e['title']); ?></strong><br>
                    <small><?php echo date("j M Y H:i", strtotime($e['date_time'])); ?> · <?php echo htmlspecialchars($e['location']); ?></small>
                    <p><?php echo htmlspecialchars($e['description']); ?></p>
                  </div>
                </div>
              <?php endwhile; ?>
            <?php else: ?>
              <p class="no-data">No upcoming events.</p>
            <?php endif; ?>
          </div>
        </div>

        <div class="card">
          <h3>Quick Actions</h3>
          <div class="quick-grid">
            <div class="quick-tile">Message a student</div>
            <div class="quick-tile">Find a tutor</div>
            <div class="quick-tile">Create event</div>
            <div class="quick-tile">Join a group</div>
          </div>
        </div>
      </aside>

    </div>

    <div class="footer">Contact: contact@campusconnect.edu • Terms • Privacy</div>
  </div>

<script>
  // Show live date & time
  function updateDateTime() {
    const now = new Date();
    document.getElementById('date-text').textContent = now.toLocaleString(undefined, { weekday:'long', year:'numeric', month:'long', day:'numeric', hour:'2-digit', minute:'2-digit', second:'2-digit' });
  }
  updateDateTime();
  setInterval(updateDateTime, 1000);
</script>

<?php $conn->close(); ?>
</body>
</html>
