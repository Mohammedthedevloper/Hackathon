<?php
header('Content-Type: application/json');
include 'db_connection.php';

// Simple rate limit
session_start();
$now = time();
$_SESSION['del_user_times'] = array_filter($_SESSION['del_user_times'] ?? [], fn($t)=>$t>$now-60);
if (count($_SESSION['del_user_times']) >= 60) { echo json_encode(['success'=>false,'error'=>'Too many deletes']); exit; }
$_SESSION['del_user_times'][] = $now;

$user_id = (int)($_POST['user_id'] ?? 0);
if ($user_id <= 0) { echo json_encode(['success'=>false,'error'=>'Invalid user id']); exit; }
if ($user_id === 1) { echo json_encode(['success'=>false,'error'=>'User #1 is protected']); exit; }

// Optional: ensure user exists
$chk = $conn->prepare("SELECT 1 FROM users WHERE user_id=?");
$chk->bind_param("i", $user_id);
$chk->execute();
$exists = $chk->get_result()->fetch_row();
$chk->close();
if (!$exists) { echo json_encode(['success'=>false,'error'=>'User not found']); exit; }

// Delete (CASCADE will clean up if FKs exist)
$stmt = $conn->prepare("DELETE FROM users WHERE user_id=?");
$stmt->bind_param("i", $user_id);
$ok = $stmt->execute();
$stmt->close();

echo json_encode(['success'=>$ok]);
$conn->close();