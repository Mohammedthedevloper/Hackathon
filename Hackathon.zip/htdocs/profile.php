<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
include 'db_connection.php';

// Helper to escape output
function e($s) { return htmlspecialchars($s ?? '', ENT_QUOTES, 'UTF-8'); }

// Redirect if not logged in
$currentUserId = $_SESSION['user_id'] ?? null;
if (!$currentUserId) {
    header("Location: index.php");
    exit;
}

// Fetch user data
$query = "
    SELECT username, full_name, email, major, year_of_major, skills, interests, campus_involvement, profile_image, role
    FROM users
    WHERE user_id = ?
";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $currentUserId);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo "<p>User not found.</p>";
    exit;
}

$user = $result->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= e($user['username']) ?>'s Profile</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700&display=swap" rel="stylesheet">
<style>
:root{
  --primary: #1e3a8a;
  --muted: #6b7280;
  --bg: #f7f8fb;
  --card: #ffffff;
  --glass: rgba(255,255,255,0.75);
  --radius: 12px;
  --shadow: 0 10px 30px rgba(2,6,23,0.08);
}
*{box-sizing:border-box}
body{margin:0;font-family:'Inter',system-ui,-apple-system,'Segoe UI',Roboto,"Helvetica Neue",Arial;color:#0f172a;background:var(--bg);-webkit-font-smoothing:antialiased}
a{color:inherit;text-decoration:none}

/* Header */
header{
  position:fixed; top:0; left:0; right:0; height:68px;
  display:flex; align-items:center; padding:0 22px; gap:16px;
  z-index:1200;
  background: linear-gradient(180deg, rgba(255,255,255,0.98), rgba(255,255,255,0.96));
  box-shadow: 0 8px 30px rgba(2,6,23,0.08);
  backdrop-filter: blur(6px);
}
.brand { display:flex; align-items:center; gap:12px; }
.logo { width:52px; height:52px; border-radius:10px; overflow:hidden; background:var(--primary); display:flex; align-items:center; justify-content:center; }
.logo img { width:100%; height:100%; object-fit:cover; }
.site-title { font-weight:700; color:var(--primary); font-size:18px; }
nav { margin-left:auto; display:flex; align-items:center; gap:10px; }
nav a { padding:8px 12px; border-radius:10px; color:var(--muted); font-weight:600; transition: all .18s; }
nav a.active, nav a:hover { background: rgba(30,58,138,0.08); color:var(--primary); }
.logout-btn{ padding:8px 12px; border-radius:8px; border:none; background:#ef4444; color:#fff; font-weight:600; cursor:pointer; transition:background .18s; }
.logout-btn:hover{ background:#dc2626; }

/* full-page background */
body::before {
  content:"";
  position:fixed;
  inset:0;
  background: url("C:\Users\fanel\Downloads\diverse-teenagers-practicing-health-wellness-activities-themselves-their-community.jpg") center/cover no-repeat;
  filter:brightness(0.65);
  z-index:-1;
}

/* profile container */
.profile-container {
  max-width:1000px;
  margin:120px auto 60px auto;
  background:var(--card);
  border-radius:var(--radius);
  box-shadow:var(--shadow);
  display:flex;
  overflow:hidden;
  flex-wrap:wrap;
}

/* left column */
.profile-left {
  flex:1 1 280px;
  background:linear-gradient(135deg,var(--primary), #2563eb);
  color:#fff;
  padding:40px 20px;
  display:flex;
  flex-direction:column;
  align-items:center;
  justify-content:center;
  text-align:center;
}
.profile-left img {
  width:130px; height:130px;
  border-radius:50%;
  object-fit:cover;
  border:3px solid #fff;
  margin-bottom:20px;
}
.profile-left h2 { margin:0 0 8px 0; font-size:26px; }
.profile-left p { margin:2px 0; font-weight:500; }

/* right column */
.profile-right {
  flex:2 1 400px;
  padding:30px 25px;
}
.profile-field { margin-bottom:16px; }
.profile-field strong { display:inline-block; width:160px; color:var(--muted); font-weight:600; }
.profile-field span { color:#0b1220; }
.actions { text-align:center; margin-top:20px; }

/* responsive */
@media(max-width:768px){
  .profile-container { flex-direction:column; }
  .profile-left, .profile-right { flex:1 1 100%; padding:25px; }
}
</style>
</head>
<body>

<header>
  <div class="brand">
    <div class="logo"><img src="images/logo.jpg" alt="Logo"></div>
    <span class="site-title">Campus Connect</span>
  </div>
  <nav>
    <a href="index.php">Home</a>
    <a href="about.php">About</a>
    <a href="profile.php" class="active">Profile</a>
    <a href="events.php">Events</a>
    <a href="plug.php">Plug In | Tutor Board</a>
    <form method="POST" style="display:inline;margin-left:6px;">
        <input type="hidden" name="action" value="logout">
        <button type="submit" class="logout-btn">Logout</button>
    </form>
  </nav>
</header>

<div class="profile-container">
  <div class="profile-left">
    <?php if(!empty($user['profile_image'])): ?>
      <img src="images/<?= e($user['profile_image']); ?>" alt="Profile Picture">
    <?php else: ?>
      <div style="width:130px;height:130px;border-radius:50%;background:#eef2ff;color:#fff;display:flex;align-items:center;justify-content:center;font-size:50px;font-weight:700"><?= strtoupper(substr($user['full_name'],0,1)) ?></div>
    <?php endif; ?>
    <h2><?= e($user['full_name']); ?></h2>
    <p><?= ucfirst(e($user['role'])); ?></p>
    <p>@<?= e($user['username']); ?></p>
  </div>
  <div class="profile-right">
    <div class="profile-field"><strong>Email:</strong> <span><?= e($user['email']); ?></span></div>
    <div class="profile-field"><strong>Major:</strong> <span><?= e($user['major']); ?></span></div>
    <div class="profile-field"><strong>Year of Major:</strong> <span><?= e($user['year_of_major']); ?></span></div>
    <div class="profile-field"><strong>Skills:</strong> <span><?= e($user['skills']); ?></span></div>
    <div class="profile-field"><strong>Interests:</strong> <span><?= e($user['interests']); ?></span></div>
    <div class="profile-field"><strong>Campus Involvement:</strong> <span><?= e($user['campus_involvement']); ?></span></div>
    <div class="actions">
      <a href="editprofile.php" class="btn-primary" style="padding:10px 20px;border-radius:12px;background:var(--primary);color:#fff;font-weight:700;text-decoration:none;">Edit Profile</a>
    </div>
  </div>
</div>

</body>
</html>
