<?php
declare(strict_types=1);
session_start();
header('Content-Type: application/json; charset=utf-8');

require_once 'db_connection.php';

// ---- Adjust this to your auth system ----
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'admin') {
    http_response_code(403);
    echo json_encode(['error' => 'Forbidden']);
    exit;
}

try {
    $out = [
        'total' => 0,
        'roles' => ['student' => 0, 'lecturer' => 0, 'admin' => 0],
    ];

    // Total
    $res = $conn->query("SELECT COUNT(*) AS total FROM users");
    if ($res && $row = $res->fetch_assoc()) $out['total'] = (int)$row['total'];

    // By role
    $res2 = $conn->query("SELECT role, COUNT(*) AS c FROM users GROUP BY role");
    if ($res2) {
        while ($r = $res2->fetch_assoc()) {
            $role = $r['role'];
            $count = (int)$r['c'];
            if (isset($out['roles'][$role])) $out['roles'][$role] = $count;
        }
    }

    echo json_encode($out, JSON_UNESCAPED_UNICODE);
} catch (Throwable $th) {
    http_response_code(500);
    echo json_encode(['error' => 'Server error']);
}