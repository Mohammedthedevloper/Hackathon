<?php
// messaging.php
ini_set('display_errors',1);
ini_set('display_startup_errors',1);
error_reporting(E_ALL);

session_start();
require_once 'db_connection.php';

function e($s){ return htmlspecialchars($s??'', ENT_QUOTES, 'UTF-8'); }

// Require login
if (empty($_SESSION['user_id'])) {
  header("Location: login.php");
  exit();
}
$currentUserId = (int)$_SESSION['user_id'];

// Current user (for header)
$stmt = $conn->prepare("SELECT user_id, username, full_name, profile_image FROM users WHERE user_id = ?");
$stmt->bind_param("i",$currentUserId);
$stmt->execute();
$currentUser = $stmt->get_result()->fetch_assoc();
$stmt->close();

// Sidebar users (exclude me + exclude admins)
$stmt = $conn->prepare("
  SELECT user_id, full_name, username, profile_image
  FROM users
  WHERE user_id <> ? AND (role IS NULL OR role <> 'admin')
  ORDER BY full_name ASC
");
$stmt->bind_param("i",$currentUserId);
$stmt->execute();
$users = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width,initial-scale=1" />
<title>Campus Connect | Chats</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700&display=swap" rel="stylesheet">
<style>
:root{ --primary:#1e3a8a; --muted:#6b7280; --bg:#f7f8fb; --card:#fff; --radius:12px; --shadow:0 10px 30px rgba(2,6,23,.08) }
*{box-sizing:border-box} body{margin:0;font-family:'Inter',system-ui,-apple-system,'Segoe UI',Roboto,Arial;background:var(--bg);color:#0f172a}
a{text-decoration:none;color:inherit}

/* Header (same as index) */
header{
  position:fixed; top:0; left:0; right:0; height:68px;
  display:flex; align-items:center; padding:0 22px; gap:16px; z-index:1200;
  background:linear-gradient(180deg,rgba(255,255,255,.98),rgba(255,255,255,.96));
  box-shadow:0 8px 30px rgba(2,6,23,.08); backdrop-filter:blur(6px);
}
.brand{display:flex;align-items:center;gap:12px}
.logo{width:52px;height:52px;border-radius:10px;overflow:hidden;background:var(--primary);display:flex;align-items:center;justify-content:center}
.logo img{width:100%;height:100%;object-fit:cover}
.site-title{font-weight:700;color:var(--primary);font-size:18px}
nav{margin-left:auto;display:flex;align-items:center;gap:10px}
nav a{padding:8px 12px;border-radius:10px;color:var(--muted);font-weight:600;transition:.18s}
nav a.active,nav a:hover{background:rgba(30,58,138,.08);color:var(--primary)}
.logout-btn{padding:8px 12px;border:none;border-radius:8px;background:#ef4444;color:#fff;font-weight:600;cursor:pointer}
.logout-btn:hover{background:#dc2626}
.header-user{display:flex;align-items:center;gap:8px;margin-left:6px}
.header-avatar{width:32px;height:32px;border-radius:50%;overflow:hidden;background:#e5e7eb;display:flex;align-items:center;justify-content:center;font-weight:700;color:#0b1220}
.header-avatar img{width:100%;height:100%;object-fit:cover}

/* Layout */
.container{max-width:980px;margin:0 auto;padding:24px;padding-top:96px;display:flex;gap:20px;align-items:flex-start}
.card{background:var(--card);border-radius:var(--radius);box-shadow:var(--shadow);border:1px solid rgba(2,6,23,.05);padding:16px}
.users{flex:1}
.chat{flex:2;display:flex;flex-direction:column;gap:10px;max-height:70vh}
.users input{width:100%;padding:10px;border:1px solid #ddd;border-radius:10px;margin-bottom:12px}
.user{display:flex;align-items:center;gap:10px;padding:8px;border-radius:10px;cursor:pointer}
.user:hover,.user.active{background:#eef2ff}
.user img{width:36px;height:36px;border-radius:50%;object-fit:cover}
.user .fallback{width:36px;height:36px;border-radius:50%;background:#e5e7eb;display:flex;align-items:center;justify-content:center;font-weight:700;color:#0b1220}
.messages{flex:1;overflow:auto;display:flex;flex-direction:column;gap:8px;border:1px solid #e5e7eb;border-radius:10px;padding:12px}
.msg{max-width:70%;padding:10px;border-radius:12px}
.msg.me{align-self:flex-end;background:#1e3a8a;color:#fff}
.msg.them{align-self:flex-start;background:#e5e7eb;color:#111}
.send{display:flex;gap:10px;margin-top:10px}
.send input{flex:1;padding:10px;border:1px solid #ddd;border-radius:10px}
.send button{padding:10px 14px;border:none;border-radius:10px;background:#1e3a8a;color:#fff;font-weight:700;cursor:pointer}
@media(max-width:980px){.container{flex-direction:column}}
</style>
</head>
<body>

<header>
  <div class="brand">
    <div class="logo"><img src="images/logo.jpg" alt="Logo"></div>
    <span class="site-title">Campus Connect</span>
  </div>
  <nav>
    <a href="index.php">Home</a>
    <a href="about.php">About</a>
    <a href="profile.php">Profile</a>
    <a href="events.php">Events</a>
    <a href="messaging.php" class="active">Chats</a>

    <div class="header-user">
      <div class="header-avatar">
        <?php if(!empty($currentUser['profile_image'])): ?>
          <img src="images/<?= e($currentUser['profile_image']) ?>" alt="Avatar">
        <?php else: ?>
          <?= strtoupper(substr($currentUser['full_name'] ?: $currentUser['username'],0,1)) ?>
        <?php endif; ?>
      </div>
      <span><?= e($currentUser['full_name'] ?: $currentUser['username']) ?></span>
    </div>

    <form method="POST" action="logout.php" style="display:inline;margin-left:6px;">
      <button type="submit" class="logout-btn">Logout</button>
    </form>
  </nav>
</header>

<div class="container">
  <!-- Users -->
  <section class="card users">
    <input type="text" placeholder="Search users..." onkeyup="filterUsers(this)" />
    <div id="userList">
      <?php foreach($users as $u): ?>
        <div class="user" data-id="<?= (int)$u['user_id'] ?>">
          <?php if(!empty($u['profile_image'])): ?>
            <img src="images/<?= e($u['profile_image']) ?>" alt="Profile">
          <?php else: ?>
            <div class="fallback"><?= strtoupper(substr(($u['full_name'] ?: $u['username']),0,1)) ?></div>
          <?php endif; ?>
          <span><?= e($u['full_name'] ?: $u['username']) ?></span>
        </div>
      <?php endforeach; ?>
    </div>
  </section>

  <!-- Chat -->
  <section class="card chat">
    <div id="messages" class="messages">
      <div style="color:var(--muted)">Select a user to start messaging.</div>
    </div>
    <form id="sendForm" class="send" onsubmit="return sendMsg(event)" style="display:none">
      <input type="text" id="msgInput" placeholder="Type a message..." required />
      <button type="submit">Send</button>
    </form>
  </section>
</div>

<script>
let currentPeer = 0;

function filterUsers(inp){
  const q = inp.value.toLowerCase();
  document.querySelectorAll('#userList .user').forEach(u=>{
    u.style.display = u.textContent.toLowerCase().includes(q) ? 'flex':'none';
  });
}

document.querySelectorAll('#userList .user').forEach(u=>{
  u.addEventListener('click', ()=>{
    document.querySelectorAll('#userList .user').forEach(x=>x.classList.remove('active'));
    u.classList.add('active');
    currentPeer = u.dataset.id;
    loadMessages();
  });
});

async function loadMessages(after=0){
  if(!currentPeer) return;
  const res = await fetch(messages.php?peer_id=${currentPeer}&after_id=${after});
  const data = await res.json();
  const box = document.getElementById('messages');
  if(after === 0) box.innerHTML = '';
  data.messages.forEach(m=>{
    const d = document.createElement('div');
    d.className = 'msg ' + (m.is_me ? 'me':'them');
    d.innerHTML = m.html;
    box.appendChild(d);
  });
  document.getElementById('sendForm').style.display = 'flex';
  box.scrollTop = box.scrollHeight;
}

async function sendMsg(e){
  e.preventDefault();
  if(!currentPeer) return false;
  const input = document.getElementById('msgInput');
  const msg = input.value.trim();
  if(!msg) return false;
  await fetch('send_message.php',{
    method:'POST',
    headers:{'Content-Type':'application/x-www-form-urlencoded'},
    body:receiver_id=${encodeURIComponent(currentPeer)}&message=${encodeURIComponent(msg)}
  });
  input.value='';
  loadMessages();
  return false;
}

// Auto-open if ?peer_id=...
(function(){
  const pid = new URLSearchParams(location.search).get('peer_id');
  if(pid){
    const t = document.querySelector(.user[data-id="${pid}"]);
    if(t){ t.click(); t.scrollIntoView({block:'center'}); }
  }
})();
</script>

</body>
</html>