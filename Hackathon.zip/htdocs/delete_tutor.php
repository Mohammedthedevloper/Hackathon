<?php
header('Content-Type: application/json');
include 'db_connection.php';

$id = (int)($_POST['id'] ?? 0);
if ($id<=0) { echo json_encode(['success'=>false,'error'=>'Invalid ID']); exit; }

$stmt = $conn->prepare("DELETE FROM tutors WHERE id=?");
$stmt->bind_param("i", $id);
$ok = $stmt->execute();
$stmt->close();

echo json_encode(['success'=>$ok]);
$conn->close();