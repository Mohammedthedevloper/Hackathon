<?php
header('Content-Type: application/json');
include 'db_connection.php';

$list = [];
$res = $conn->query("SELECT user_id, username, email, full_name FROM users ORDER BY user_id DESC LIMIT 50");
if ($res) {
  while($r = $res->fetch_assoc()){
    $list[] = [
      'user_id' => (int)$r['user_id'],
      'username' => htmlspecialchars($r['username'], ENT_QUOTES, 'UTF-8'),
      'email' => htmlspecialchars($r['email'], ENT_QUOTES, 'UTF-8'),
      'full_name' => htmlspecialchars($r['full_name'] ?? '', ENT_QUOTES, 'UTF-8'),
    ];
  }
}
echo json_encode(['users'=>$list]);
$conn->close();