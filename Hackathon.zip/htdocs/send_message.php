<?php
session_start();
include 'db_connection.php';

if(empty($_SESSION['user_id'])){
    exit("not logged in");
}

$currentUserId = $_SESSION['user_id'];
$receiverId = isset($_POST['receiver_id']) ? (int)$_POST['receiver_id'] : 0;
$message = isset($_POST['message']) ? trim($_POST['message']) : "";

if(!$receiverId || $message==="") exit("invalid");

$stmt = $conn->prepare("INSERT INTO messages (sender_id, receiver_id, message, created_at, is_read) VALUES (?, ?, ?, NOW(), 0)");
$stmt->bind_param("iis", $currentUserId, $receiverId, $message);
if($stmt->execute()){
    echo "ok";
} else {
    echo "error";
}
$stmt->close();
