<?php
session_start();
include 'db_connection.php';

$currentUserId = $_SESSION['user_id'] ?? null;
if (!$currentUserId) { 
    header("Location: index.php"); 
    exit; 
}

// Fetch current user data
$stmt = $conn->prepare("
    SELECT username, full_name, email, major, year_of_major, skills, interests, campus_involvement, profile_image, role
    FROM users
    WHERE user_id = ?
");
$stmt->bind_param("i", $currentUserId);
$stmt->execute();
$currentUser = $stmt->get_result()->fetch_assoc();
$stmt->close();

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'] ?? '';
    $email = $_POST['email'] ?? '';
    $major = $_POST['major'] ?? '';
    $year_of_major = $_POST['year_of_major'] ?? '';
    $skills = $_POST['skills'] ?? '';
    $interests = $_POST['interests'] ?? '';
    $campus_involvement = $_POST['campus_involvement'] ?? '';
    $profileImagePath = $currentUser['profile_image'] ?? null;

    if (isset($_FILES['profile_image']) && $_FILES['profile_image']['error'] == 0) {
        $allowedExtensions = ['jpg','jpeg','png','gif'];
        $fileExt = strtolower(pathinfo($_FILES['profile_image']['name'], PATHINFO_EXTENSION));
        if (in_array($fileExt, $allowedExtensions) && $_FILES['profile_image']['size'] < 5*1024*1024) {
            if (!is_dir('uploads')) mkdir('uploads',0777,true);
            $profileImagePath = 'uploads/profile_'.$currentUserId.'_'.time().'.'.$fileExt;
            move_uploaded_file($_FILES['profile_image']['tmp_name'], $profileImagePath);
        }
    }

    $stmt = $conn->prepare("
        UPDATE users 
        SET full_name=?, email=?, major=?, year_of_major=?, skills=?, interests=?, campus_involvement=?, profile_image=? 
        WHERE user_id=?
    ");
    $stmt->bind_param("ssssssssi", $name, $email, $major, $year_of_major, $skills, $interests, $campus_involvement, $profileImagePath, $currentUserId);
    $stmt->execute();
    $stmt->close();

    header("Refresh:1");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Edit Profile</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700&display=swap" rel="stylesheet">
<style>
:root{
  --primary: #1e3a8a;
  --muted: #6b7280;
  --bg: #f7f8fb;
  --card: #ffffff;
  --radius: 12px;
  --shadow: 0 10px 30px rgba(2,6,23,0.08);
}
body{margin:0;font-family:'Inter',sans-serif;color:#0f172a;background:var(--bg);}
body::before{
  content:""; position:fixed; inset:0;
  background:url("C:\Users\fanel\Downloads\diverse-teenagers-practicing-health-wellness-activities-themselves-their-community.jpg") center/cover no-repeat;
  filter:brightness(0.65); z-index:-1;
}
header{
  position:fixed; top:0; left:0; right:0; height:68px;
  display:flex; align-items:center; padding:0 22px; gap:16px;
  z-index:1200; background: rgba(255,255,255,0.97);
  box-shadow: 0 8px 30px rgba(2,6,23,0.08); backdrop-filter: blur(6px);
}
.brand { display:flex; align-items:center; gap:12px; }
.logo { width:52px; height:52px; border-radius:10px; overflow:hidden; display:flex;align-items:center;justify-content:center; }
.logo img{width:100%;height:100%;object-fit:cover;}
.site-title{font-weight:700;color:var(--primary);font-size:18px;}
nav{margin-left:auto; display:flex; gap:10px;}
nav a{padding:8px 12px;border-radius:10px;color:var(--muted);font-weight:600;text-decoration:none;}
nav a.active, nav a:hover{background:rgba(30,58,138,0.08); color:var(--primary);}
.logout-btn{padding:8px 12px;border-radius:8px;border:none;background:#ef4444;color:#fff;font-weight:600;cursor:pointer;}
.logout-btn:hover{background:#dc2626;}

.container{
  max-width:500px; margin:120px auto 60px auto; background:var(--card);
  border-radius:var(--radius); padding:30px; box-shadow:var(--shadow);
}
h1{text-align:center;color:var(--primary);}
label{display:block;margin-top:12px;font-weight:600;}
input,textarea,select{width:100%;padding:10px;margin-top:5px;border:1px solid #ccc;border-radius:8px;font-size:15px;box-sizing:border-box;}
button{background:var(--primary); color:#fff; padding:12px; margin-top:18px; border:none; border-radius:8px; cursor:pointer; font-weight:700; width:100%;}
button:hover{background:#3749c1;}
.profile-img{display:block;margin:15px auto;border-radius:50%;border:4px solid var(--primary);width:130px;height:130px;object-fit:cover;}
.back-link{text-align:center;margin-top:12px;}
.back-link a{color:var(--primary);font-weight:700;text-decoration:none;}
</style>
</head>
<body>

<header>
  <div class="brand">
    <div class="logo"><img src="images/logo.jpg" alt="Logo"></div>
    <span class="site-title">Campus Connect</span>
  </div>
  <nav>
    <a href="index.php">Home</a>
    <a href="about.php">About</a>
    <a href="profile.php" class="active">Profile</a>
    <a href="events.php">Events</a>
    <a href="plug.php">Plug In | Tutor Board</a>
    <form method="POST" style="display:inline;margin-left:6px;">
      <input type="hidden" name="action" value="logout">
      <button type="submit" class="logout-btn">Logout</button>
    </form>
  </nav>
</header>

<div class="container">
  <h1>Edit Profile</h1>

  <?php if(!empty($currentUser['profile_image'])): ?>
    <img src="<?= htmlspecialchars($currentUser['profile_image']); ?>" class="profile-img" alt="Profile Picture">
  <?php endif; ?>

  <form method="POST" enctype="multipart/form-data">
    <label>Full Name</label>
    <input type="text" name="name" value="<?= htmlspecialchars($currentUser['full_name'] ?? ''); ?>" required>

    <label>Email</label>
    <input type="email" name="email" value="<?= htmlspecialchars($currentUser['email'] ?? ''); ?>" required>

    <label>Major</label>
    <input type="text" name="major" value="<?= htmlspecialchars($currentUser['major'] ?? ''); ?>">

    <label>Year of Major</label>
    <input type="text" name="year_of_major" value="<?= htmlspecialchars($currentUser['year_of_major'] ?? ''); ?>">

    <label>Skills</label>
    <input type="text" name="skills" value="<?= htmlspecialchars($currentUser['skills'] ?? ''); ?>">

    <label>Interests</label>
    <input type="text" name="interests" value="<?= htmlspecialchars($currentUser['interests'] ?? ''); ?>">

    <label>Campus Involvement</label>
    <input type="text" name="campus_involvement" value="<?= htmlspecialchars($currentUser['campus_involvement'] ?? ''); ?>">

    <label>Bio</label>
    <textarea name="bio" rows="4"><?= htmlspecialchars($currentUser['bio'] ?? ''); ?></textarea>

    <label>Profile Picture</label>
    <input type="file" name="profile_image" accept="image/*">

    <button type="submit">Save Profile</button>
  </form>

  <div class="back-link">
    <a href="profile.php">← Back to Profile</a>
  </div>
</div>

</body>
</html>


