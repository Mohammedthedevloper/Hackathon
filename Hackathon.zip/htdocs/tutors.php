<?php
session_start();
include 'db_connection.php';

if (empty($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$currentUserId = $_SESSION['user_id'];

// Get search term
$search = isset($_GET['search']) ? trim($_GET['search']) : "";

// Base SQL
$sql = "SELECT t.id, t.tutor_name, t.moduleIndex, t.facultyIndex, t.year_levelIndex, u.profile_image
        FROM tutors t
        LEFT JOIN users u ON t.user_id = u.user_id
        WHERE t.user_id != ?";

// If searching, append conditions
$params = [$currentUserId];
$types = "i";
if ($search !== "") {
    $sql .= " AND (t.tutor_name LIKE ? OR t.moduleIndex LIKE ? OR t.facultyIndex LIKE ?)";
    $like = "%$search%";
    array_push($params, $like, $like, $like);
    $types .= "sss";
}

$stmt = $conn->prepare($sql);
if ($stmt === false) {
    die("Prepare failed: " . $conn->error);
}

// Bind parameters dynamically
$stmt->bind_param($types, ...$params);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>All Tutors</title>
<style>
body{ font-family:sans-serif; margin:20px; }
.tutor-card{ padding:10px; border:1px solid #ccc; margin-bottom:10px; border-radius:8px; display:flex; align-items:center; gap:10px; }
.tutor-card img{ width:50px; height:50px; border-radius:50%; object-fit:cover; }
.tutor-info{ flex:1; }
.tutor-link{ text-decoration:none; color:#1e3a8a; font-weight:bold; }
.search-bar{ margin-bottom:20px; }
</style>
</head>
<body>

<h1>All Tutors</h1>

<form method="GET" class="search-bar">
  <input type="text" name="search" placeholder="Search tutors..." value="<?php echo htmlspecialchars($search); ?>">
  <button type="submit">Search</button>
</form>

<?php if($result && $result->num_rows > 0): ?>
  <?php while($tutor = $result->fetch_assoc()): ?>
    <div class="tutor-card">
      <?php if(!empty($tutor['profile_image'])): ?>
        <img src="images/<?php echo htmlspecialchars($tutor['profile_image']); ?>" alt="Profile">
      <?php else: ?>
        <div style="width:50px;height:50px;border-radius:50%;background:#ccc;display:flex;align-items:center;justify-content:center;">
          <?php echo strtoupper(substr($tutor['tutor_name'],0,1)); ?>
        </div>
      <?php endif; ?>
      <div class="tutor-info">
        <a class="tutor-link" href="tutor_messaging.php?chat_with=<?php echo (int)$tutor['id']; ?>">
          <?php echo htmlspecialchars($tutor['tutor_name']); ?>
        </a>
        <div><?php echo htmlspecialchars($tutor['moduleIndex']); ?> - <?php echo htmlspecialchars($tutor['facultyIndex']); ?></div>
        <div><?php echo htmlspecialchars($tutor['year_levelIndex']); ?></div>
      </div>
    </div>
  <?php endwhile; ?>
<?php else: ?>
  <p>No tutors found.</p>
<?php endif; ?>

</body>
</html>
